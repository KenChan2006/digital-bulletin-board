<?php
session_start();

// ============================
// REQUIRE LOGIN
// ============================
if (!isset($_SESSION['email'])) {
    http_response_code(404);
    echo "<h1>404 Not Found</h1><p>This page is not accessible.</p>";
    exit();
}

// ============================
// ANTI-CACHE HEADERS
// ============================
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

// ============================
// DB CONNECTION
// ============================
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ============================
// FETCH FACULTY INFO
// ============================
$faculty_email = $_SESSION['email'];
$facultyId = 0;
$facultyName = "";
$facultyPic = "/default_profile.png";

$stmt = $conn->prepare("SELECT id, firstname, lastname, profile_image FROM user WHERE email=?");
$stmt->bind_param("s", $faculty_email);
$stmt->execute();
$faculty = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($faculty) {
    $facultyId = $faculty["id"];
    $facultyName = $faculty["firstname"] . " " . $faculty["lastname"];
    $facultyPic = !empty($faculty["profile_image"]) ? "/uploads/" . $faculty["profile_image"] : "/default_profile.png";
}

// ============================
// CREATE ANNOUNCEMENT
// ============================
if (isset($_POST['create_announcement'])) {
    $title = $_POST['title'];
    $content = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO educ_announcement (Title, Content, status, DatePosted) VALUES (?, ?, 'pending', NOW())");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    $stmt->close();

    header("Location: educ.php");
    exit();
}

// ============================
// DELETE ANNOUNCEMENT
// ============================
if (isset($_POST['delete_announcement'])) {
    $announcement_id = intval($_POST['announcement_id']);

    $conn->query("DELETE r FROM educ_announcement_feedback_replies r 
                  JOIN educ_announcement_feedback f ON r.feedback_id=f.feedback_id 
                  WHERE f.announcement_id=$announcement_id");

    $conn->query("DELETE FROM educ_announcement_feedback WHERE announcement_id=$announcement_id");
    $conn->query("DELETE FROM educ_announcement WHERE announcement_id=$announcement_id");

    header("Location: educ.php");
    exit();
}

// ============================
// DELETE REPLY
// ============================
if (isset($_POST['delete_reply'])) {
    $reply_id = intval($_POST['reply_id']);

    $stmt = $conn->prepare("DELETE FROM educ_announcement_feedback_replies WHERE reply_id=? AND faculty_id=?");
    $stmt->bind_param("ii", $reply_id, $facultyId);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// ============================
// ADD REPLY
// ============================
if (isset($_POST['reply_feedback'])) {
    $feedback_id = intval($_POST['feedback_id']);
    $reply_text = $_POST['reply_text'];

    $stmt = $conn->prepare("INSERT INTO educ_announcement_feedback_replies (feedback_id, faculty_id, replytext, date_posted) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iis", $feedback_id, $facultyId, $reply_text);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

$announcements = $conn->query("SELECT * FROM educ_announcement ORDER BY announcement_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>EDUC Faculty Dashboard</title>

<style>
/* ==================================== */
/*   SKY-BLUE THEME (NEW REQUEST)      */
/* ==================================== */

:root {
    --blue-dark: #0a2e8a;
    --blue-mid: #1a3fcf;
    --blue-sky: #bcd9ff;
    --blue-verylight: #e8f1ff;
    --blue-soft: #d5e7ff;
    --danger: #b71c1c;
    --white: #ffffff;
}

/* BODY (SKY BLUE) */
body {
    margin:0;
    padding:0;
    background: var(--blue-sky);
    font-family: "Poppins", sans-serif;
    animation: fadeIn .6s ease-in;
}

/* HEADER (DARK BLUE) */
header {
    background: var(--blue-dark);
    color: var(--white);
    padding: 25px;
    font-size: 28px;
    text-align:center;
    font-weight:bold;
    position:relative;
    box-shadow:0 4px 12px rgba(120,160,255,0.6); /* light blue shadow */
    animation: slideDown .7s ease;
}

/* LOGOUT BUTTON */
#logoutBtn {
    position:absolute;
    right:20px;
    top:20px;
    padding:10px 14px;
    background:var(--danger);
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
    font-weight:bold;
}
#logoutBtn:hover { background:#8e1111; }

/* MAIN CONTENT */
.container {
    max-width:900px;
    margin:25px auto;
}

/* CARD / BOX (LIGHT-BLUE SHADOWS) */
.box {
    background: var(--white);
    padding:25px;
    border-radius:14px;
    margin-bottom:20px;
    box-shadow:0px 6px 20px rgba(100,150,255,0.4); /* light blue shadow */
    animation: popUp .5s;
}

/* FEEDBACK + REPLIES */
.feedback-box {
    background:#eef4ff;
    padding:12px;
    border-radius:12px;
    margin-top:10px;
    box-shadow:0 0 10px rgba(130,160,255,0.3);
}
.reply-box {
    background:#dce7ff;
    padding:10px;
    margin-left:20px;
    margin-top:8px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(130,160,255,0.25);
}

/* INPUT FIELDS */
input, textarea {
    width:100%;
    padding:12px;
    border-radius:8px;
    border:1px solid #a6c4ff;
    margin-top:4px;
    margin-bottom:12px;
}

/* BUTTONS */
button {
    padding:9px 15px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
}

button.reply { background: var(--blue-mid); color:white; }
button.reply:hover { background:#1535a3; }

button.delete { background:var(--danger); color:white; }
button.delete:hover { background:#8e1111; }

#createBtn { background: var(--blue-mid); color:white; }
#createBtn:hover { background:#1535a3; }

/* STATUS COLORS */
.status-pending { color:orange; font-weight:bold; }
.status-approved { color:green; font-weight:bold; }
.status-rejected { color:red; font-weight:bold; }

/* ANIMATIONS */
@keyframes fadeIn { from {opacity:0;} to {opacity:1;} }
@keyframes slideDown { from {transform:translateY(-40px);} to {transform:translateY(0);} }
@keyframes popUp { from {transform:scale(0.92); opacity:0;} to {transform:scale(1); opacity:1;} }

</style>
</head>

<body>

<header>
    EDUCATION Faculty Dashboard
    <button id="logoutBtn">Logout</button>
</header>

<div class="container">

<!-- CREATE ANNOUNCEMENT -->
<div class="box">
    <h2>Create Announcement</h2>
    <form method="POST">
        <label>Title:</label>
        <input type="text" name="title" required>

        <label>Content:</label>
        <textarea name="message" required></textarea>

        <button id="createBtn" name="create_announcement">Post Announcement</button>
    </form>
</div>

<!-- ANNOUNCEMENTS DISPLAY -->
<?php while ($ann = $announcements->fetch_assoc()): ?>
<div class="box">
    <h3><?= htmlspecialchars($ann["Title"]) ?></h3>
    <p><?= nl2br(htmlspecialchars($ann["Content"])) ?></p>

    <small>
        Status:
        <?php
            if ($ann["status"] == "pending") echo "<span class='status-pending'>Pending (Waiting for Admin Approval)</span>";
            elseif ($ann["status"] == "approved") echo "<span class='status-approved'>Approved</span>";
            else echo "<span class='status-rejected'>Rejected</span>";
        ?>
        | Date: <?= $ann["DatePosted"] ?>
    </small><br><br>

    <form method="POST">
        <input type="hidden" name="announcement_id" value="<?= $ann['announcement_id'] ?>">
        <button class="delete" name="delete_announcement">Delete Announcement</button>
    </form>

    <!-- FEEDBACK SECTION -->
    <?php
    $feedbacks = $conn->query("
        SELECT f.*, u.firstname, u.middlename, u.lastname
        FROM educ_announcement_feedback f
        LEFT JOIN user u ON f.user_email=u.email
        WHERE announcement_id={$ann['announcement_id']}
        ORDER BY feedback_id DESC
    ");

    while ($fb = $feedbacks->fetch_assoc()):
        $studentName = trim(($fb['firstname'] ?? '').' '.($fb['middlename'] ?? '').' '.($fb['lastname'] ?? ''));
        if (!$studentName) $studentName = $fb['user_email'];
    ?>
    <div class="feedback-box">
        <b><?= htmlspecialchars($studentName) ?></b><br>
        <?= nl2br(htmlspecialchars($fb['feedback_text'])) ?><br>
        <small>Sent: <?= $fb['date_sent'] ?></small>

        <!-- REPLY FORM -->
        <form method="POST">
            <input type="hidden" name="feedback_id" value="<?= $fb['feedback_id'] ?>">
            <textarea name="reply_text" placeholder="Write a reply..." required></textarea>
            <button class="reply" name="reply_feedback">Reply</button>
        </form>

        <?php
        $replies = $conn->query("
            SELECT r.*, u.firstname, u.lastname
            FROM educ_announcement_feedback_replies r
            LEFT JOIN user u ON r.faculty_id=u.id
            WHERE feedback_id={$fb['feedback_id']}
            ORDER BY r.date_posted ASC
        ");

        while ($rep = $replies->fetch_assoc()):
        ?>
        <div class="reply-box">
            <b><?= htmlspecialchars($rep['firstname'].' '.$rep['lastname']) ?>Your Reply:</b><br>
            <?= nl2br(htmlspecialchars($rep['replytext'])) ?><br>
            <small><?= $rep['date_posted'] ?></small>

            <?php if ($rep['faculty_id'] == $facultyId): ?>
            <form method="POST">
                <input type="hidden" name="reply_id" value="<?= $rep['reply_id'] ?>">
                <button class="delete" name="delete_reply">Delete Reply</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endwhile; ?>

</div>
<?php endwhile; ?>
</div>

<script>
// LOGOUT BUTTON
document.getElementById("logoutBtn").addEventListener("click", () => {
    if (confirm("Logout now?")) {
        fetch("/logout.php").then(() => {
            window.location.href = "/login/faculty_login.php";
        });
    }
});
</script>

</body>
</html>
