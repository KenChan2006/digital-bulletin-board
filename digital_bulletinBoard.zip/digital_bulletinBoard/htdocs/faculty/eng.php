<?php
session_start();

// ============================
// REQUIRE LOGIN
// ============================
if (!isset($_SESSION['email'])) {
    http_response_code(404);
    echo "<h1>404 Not Found</h1><p>This page is not accessible.</p>";
    exit();
}

// ============================
// ANTI-CACHE HEADERS
// ============================
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// ============================
// DATABASE CONNECTION
// ============================
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ============================
// FETCH FACULTY PROFILE
// ============================
$faculty_email = $_SESSION['email'];
$facultyId = 0;
$facultyName = '';
$facultyPic = '/default_profile.png';

$stmt = $conn->prepare("SELECT id, firstname, lastname, profile_image FROM user WHERE email=?");
$stmt->bind_param("s", $faculty_email);
$stmt->execute();
$faculty = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($faculty) {
    $facultyId = $faculty['id'];
    $facultyName = $faculty['firstname']." ".$faculty['lastname'];
    $facultyPic = !empty($faculty['profile_image']) ? "/uploads/".$faculty['profile_image'] : "/default_profile.png";
}

// ============================
// CREATE ANNOUNCEMENT
// ============================
if (isset($_POST['create_announcement'])) {
    $title = trim($_POST['title']);
    $content = trim($_POST['message']);

    if ($title && $content) {
        $stmt = $conn->prepare("INSERT INTO eng_announcement (Title, Content, status, DatePosted) VALUES (?, ?, 'pending', NOW())");
        $stmt->bind_param("ss", $title, $content);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: eng.php");
    exit();
}

// ============================
// DELETE ANNOUNCEMENT
// ============================
if (isset($_POST['delete_announcement'])) {
    $announcement_id = intval($_POST['announcement_id']);

    // Delete replies
    $stmt = $conn->prepare("DELETE FROM eng_feedback_replies WHERE announcement_id = ?");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    // Delete feedbacks
    $stmt = $conn->prepare("DELETE FROM eng_announcement_feedback WHERE announcement_id = ?");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    // Delete announcement
    $stmt = $conn->prepare("DELETE FROM eng_announcement WHERE announcement_id = ?");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    header("Location: eng.php");
    exit();
}

// ============================
// ADD REPLY
// ============================
if (isset($_POST['reply_feedback'])) {
    $feedback_id = intval($_POST['feedback_id']);
    $reply_text = trim($_POST['reply_text']);
    $date = date("Y-m-d H:i:s");

    if ($reply_text && $feedback_id) {
        $stmt2 = $conn->prepare("SELECT announcement_id FROM eng_announcement_feedback WHERE feedback_id=?");
        $stmt2->bind_param("i", $feedback_id);
        $stmt2->execute();
        $result = $stmt2->get_result()->fetch_assoc();
        $announcement_id = $result['announcement_id'];
        $stmt2->close();

        $stmt = $conn->prepare("INSERT INTO eng_feedback_replies (announcement_id, feedback_id, faculty_id, reply_text, date_sent) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiiss", $announcement_id, $feedback_id, $facultyId, $reply_text, $date);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: ".$_SERVER['REQUEST_URI']);
    exit();
}

// ============================
// DELETE REPLY
// ============================
if (isset($_POST['delete_reply'])) {
    $reply_id = intval($_POST['reply_id']);

    $stmt = $conn->prepare("DELETE FROM eng_feedback_replies WHERE reply_id = ? AND faculty_id = ?");
    $stmt->bind_param("ii", $reply_id, $facultyId);
    $stmt->execute();
    $stmt->close();

    header("Location: ".$_SERVER['REQUEST_URI']);
    exit();
}

// ============================
// FETCH ANNOUNCEMENTS
// ============================
$announcements = $conn->query("SELECT * FROM eng_announcement ORDER BY announcement_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ENG Faculty Dashboard</title>

<style>
/* ===== GLOBAL ===== */
body {
    font-family: Arial, sans-serif;
    background: #ffebee;
    margin: 0;
    padding: 0;
    animation: fadeIn 0.6s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* HEADER */
header {
    background: #b71c1c;
    color: white;
    text-align: center;
    padding: 20px;
    font-size: 26px;
    font-weight: bold;
    position: relative;
    box-shadow: 0 3px 8px rgba(0,0,0,0.3);
    animation: slideDown 0.6s ease;
}

@keyframes slideDown {
    from { transform: translateY(-20px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.container {
    max-width: 900px;
    margin: 20px auto;
}

/* BOX */
.box {
    background: white;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 3px 6px rgba(183,28,28,0.2);
    transition: 0.2s ease;
    animation: fadeInUp 0.5s ease;
}

.box:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 14px rgba(183,28,28,0.3);
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(15px); }
    to { opacity: 1; transform: translateY(0); }
}

/* FEEDBACK */
.feedback-box {
    margin-top: 10px;
    padding: 12px;
    background: #ffdde0;
    border-radius: 8px;
}

/* REPLY */
.reply-box {
    margin-left: 20px;
    padding: 10px;
    background: #ffcdd2;
    border-radius: 6px;
    margin-top: 6px;
}

/* FORMS */
textarea, input[type="text"] {
    width: 100%;
    padding: 8px;
    border-radius: 6px;
    border: 1px solid #b71c1c;
    margin-bottom: 10px;
    transition: 0.2s ease;
}

textarea:focus, input[type="text"]:focus {
    border-color: #ff5252;
    box-shadow: 0 0 5px rgba(255,82,82,0.7);
}

/* BUTTONS */
button {
    padding: 7px 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: 0.2s;
}

button.delete {
    background: #c62828;
    color: white;
}
button.delete:hover {
    background: #d32f2f;
    transform: scale(1.05);
}

button.reply {
    background: #b71c1c;
    color: white;
}
button.reply:hover {
    background: #d32f2f;
    transform: scale(1.05);
}

#logoutBtn {
    position: absolute;
    right: 15px;
    top: 15px;
    padding: 8px 12px;
    background: #880e0e;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: 0.2s ease;
}
#logoutBtn:hover {
    background: #d32f2f;
    transform: scale(1.08);
}

/* STATUS COLORS */
.status-pending { color: #ef6c00; font-weight: bold; }
.status-approved { color: #2e7d32; font-weight: bold; }
.status-rejected { color: #c62828; font-weight: bold; }
</style>

</head>
<body>

<header>
    ENGINEERING Faculty Dashboard
    <button id="logoutBtn">Logout</button>
</header>

<div class="container">

<!-- CREATE ANNOUNCEMENT -->
<div class="box">
    <h2>Create Announcement</h2>
    <form method="POST">
        <label>Title:</label>
        <input type="text" name="title" required>

        <label>Content:</label>
        <textarea name="message" required></textarea>

        <button type="submit" name="create_announcement" class="reply">Post Announcement</button>
    </form>
</div>

<!-- DISPLAY ANNOUNCEMENTS -->
<?php while ($ann = $announcements->fetch_assoc()): ?>
<div class="box">
    <h3><?php echo htmlspecialchars($ann['Title']); ?></h3>
    <p><?php echo nl2br(htmlspecialchars($ann['Content'])); ?></p>
    <small>
        Status: 
        <?php 
        if ($ann['status'] == 'pending') echo '<span class="status-pending">Pending</span>';
        elseif ($ann['status'] == 'approved') echo '<span class="status-approved">Approved</span>';
        else echo '<span class="status-rejected">Rejected</span>';
        ?>
        | Date: <?php echo $ann['DatePosted']; ?>
    </small>

    <!-- DELETE ANNOUNCEMENT -->
    <form method="POST" style="display:inline;">
        <input type="hidden" name="announcement_id" value="<?php echo $ann['announcement_id']; ?>">
        <button class="delete" name="delete_announcement">Delete Announcement</button>
    </form>

    <!-- FEEDBACKS (UPDATED WITH STUDENT NAME) -->
    <?php
    $feedbacks = $conn->query("
        SELECT f.*, u.firstname, u.lastname
        FROM eng_announcement_feedback f
        LEFT JOIN user u ON u.email = f.user_email
        WHERE f.announcement_id = {$ann['announcement_id']}
        ORDER BY f.feedback_id DESC
    ");

    while ($fb = $feedbacks->fetch_assoc()):
    ?>
    <div class="feedback-box">
        <b><?php echo htmlspecialchars($fb['firstname'] . " " . $fb['lastname']); ?></b><br>

        <?php echo nl2br(htmlspecialchars($fb['feedback_text'])); ?><br>
        <small>Sent: <?php echo $fb['date_sent']; ?></small>

        <!-- REPLY FORM -->
        <form method="POST">
            <input type="hidden" name="feedback_id" value="<?php echo $fb['feedback_id']; ?>">
            <textarea name="reply_text" required placeholder="Write a reply..."></textarea>
            <button class="reply" name="reply_feedback">Reply</button>
        </form>

        <!-- REPLIES -->
        <?php
        $replies = $conn->query("SELECT * FROM eng_feedback_replies WHERE feedback_id={$fb['feedback_id']} ORDER BY date_sent ASC");
        while ($rep = $replies->fetch_assoc()):
        ?>
        <div class="reply-box">
            <b>Your Reply:</b><br>
            <?php echo nl2br(htmlspecialchars($rep['reply_text'])); ?><br>
            <small>Replied: <?php echo $rep['date_sent']; ?></small>

            <?php if ($rep['faculty_id'] == $facultyId): ?>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="reply_id" value="<?php echo $rep['reply_id']; ?>">
                <button class="delete" name="delete_reply">Delete Reply</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endwhile; ?>

</div>
<?php endwhile; ?>

</div>

<script>
// LOGOUT BUTTON
document.getElementById("logoutBtn").addEventListener("click", function() {
    if (confirm("Are you sure you want to log out?")) {
        fetch('/logout.php').then(() => {
            window.location.href = "/login/faculty_login.php";
        });
    }
});

// PREVENT BACK BUTTON
(function () {
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
})();
</script>

</body>
</html>
