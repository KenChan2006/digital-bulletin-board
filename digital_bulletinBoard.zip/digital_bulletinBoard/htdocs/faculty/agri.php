<?php
session_start();

// ============================
// REQUIRE LOGIN
// ============================
if (!isset($_SESSION['email'])) {
    http_response_code(404); 
    echo "<h1>404 Not Found</h1><p>This page is not accessible.</p>";
    exit();
}

// ============================
// ANTI-CACHE HEADERS
// ============================
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// ============================
// DATABASE CONNECTION
// ============================
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ============================
// FETCH FACULTY PROFILE
// ============================
$faculty_email = $_SESSION['email'];
$facultyPic = '/default_profile.png';
$facultyName = '';
$facultyId = 0;

$stmt = $conn->prepare("SELECT id, firstname, lastname, profile_image FROM user WHERE email=?");
$stmt->bind_param("s", $faculty_email);
$stmt->execute();
$faculty = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($faculty) {
    $facultyId = $faculty['id'];
    $facultyName = $faculty['firstname'] . " " . $faculty['lastname'];
    $facultyPic = !empty($faculty['profile_image']) ? "/uploads/" . $faculty['profile_image'] : "/default_profile.png";
}

// ============================
// CREATE ANNOUNCEMENT (PENDING)
// ============================
if (isset($_POST['create_announcement'])) {
    $title = $_POST['title'];
    $content = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO agriculture_announcement 
                            (Title, Content, status, DatePosted) 
                            VALUES (?, ?, 'pending', NOW())");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    $stmt->close();

    header("Location: agri.php");
    exit();
}

// ============================
// DELETE ANNOUNCEMENT
// ============================
if (isset($_POST['delete_announcement'])) {
    $announcement_id = intval($_POST['announcement_id']);

    $stmt = $conn->prepare("
        DELETE r FROM agriculture_feedback_replies r
        JOIN agriculture_announcement_feedback f ON r.feedback_id = f.feedback_id
        WHERE f.announcement_id = ?
    ");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM agriculture_announcement_feedback WHERE announcement_id = ?");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM agriculture_announcement WHERE announcement_id = ?");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    header("Location: agri.php");
    exit();
}

// ============================
// DELETE REPLY (faculty ONLY)
// ============================
if (isset($_POST['delete_reply'])) {
    $reply_id = intval($_POST['reply_id']);

    $stmt = $conn->prepare("DELETE FROM agriculture_feedback_replies WHERE reply_id = ? AND faculty_id = ?");
    $stmt->bind_param("ii", $reply_id, $facultyId);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// ============================
// ADD REPLY (faculty)
// ============================
if (isset($_POST['reply_feedback'])) {
    $feedback_id = intval($_POST['feedback_id']);
    $reply_text = $_POST['reply_text'];
    $date = date("Y-m-d H:i:s");

    $stmt = $conn->prepare("INSERT INTO agriculture_feedback_replies (feedback_id, faculty_id, reply_text, date_sent) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $feedback_id, $facultyId, $reply_text, $date);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// ============================
// FETCH ANNOUNCEMENTS
// ============================
$announcements = $conn->query("SELECT * FROM agriculture_announcement ORDER BY announcement_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Agriculture Faculty Dashboard</title>
<style>
/* ======= GLOBAL ======= */
body {
    font-family: Arial, sans-serif;
    background: #e8f5e9; /* soft green background */
    margin: 0;
    padding: 0;
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(5px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ======= HEADER ======= */
header {
    background: #2e7d32; /* deep green */
    color: white;
    text-align: center;
    padding: 20px;
    font-size: 26px;
    font-weight: bold;
    position: relative;
    box-shadow: 0 3px 6px rgba(0,0,0,0.2);
    animation: slideDown 0.6s ease;
}
@keyframes slideDown {
    from { opacity:0; transform: translateY(-10px);}
    to { opacity:1; transform: translateY(0);}
}

#logoutBtn {
    position: absolute;
    right: 15px;
    top: 15px;
    padding: 8px 12px;
    background: #1b5e20;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
    transition: 0.2s ease;
}
#logoutBtn:hover {
    background: #43a047;
    transform: scale(1.05);
}

/* ======= CONTAINER ======= */
.container {
    max-width: 900px;
    margin: 20px auto;
}

/* ======= BOX ======= */
.box {
    background: #ffffff;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 3px 8px rgba(46,125,50,0.2);
    transition: 0.2s ease-in-out;
}
.box:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(46,125,50,0.3);
}

/* ======= FEEDBACK & REPLIES ======= */
.feedback-box {
    background: #c8e6c9;
    padding: 12px;
    border-radius: 8px;
    margin-top: 10px;
}
.reply-box {
    background: #a5d6a7;
    padding: 10px;
    border-radius: 6px;
    margin-left: 20px;
    margin-top: 5px;
}

/* ======= FORM ELEMENTS ======= */
textarea, input[type="text"] {
    width:100%;
    padding:8px;
    border-radius:6px;
    border:1px solid #81c784;
    margin-bottom:10px;
}
textarea:focus, input:focus {
    border-color:#388e3c;
    box-shadow:0 0 5px rgba(56,142,60,0.5);
}

/* ======= BUTTONS ======= */
button {
    padding:7px 14px;
    border:none;
    border-radius:5px;
    cursor:pointer;
    transition:0.2s ease;
}

button.delete {
    background: #c62828;
    color:white;
}
button.delete:hover { background:#e53935; }

button.reply {
    background: #2e7d32;
    color:white;
}
button.reply:hover { background:#43a047; }

/* ======= STATUS ======= */
.status-pending { color: #ff8f00; font-weight:bold; }
.status-approved { color: #2e7d32; font-weight:bold; }
.status-rejected { color: #c62828; font-weight:bold; }

</style>
</head>
<body>

<header>
    Agriculture Faculty Dashboard
    <button id="logoutBtn">Logout</button>
</header>

<div class="container">

<!-- CREATE ANNOUNCEMENT -->
<div class="box">
    <h2>Create Announcement</h2>
    <form method="POST">
        <label>Title:</label><br>
        <input type="text" name="title" required><br><br>

        <label>Content:</label><br>
        <textarea name="message" required></textarea><br><br>

        <button type="submit" name="create_announcement" class="reply">Post Announcement</button>
    </form>
</div>

<!-- DISPLAY ANNOUNCEMENTS -->
<?php while ($ann = $announcements->fetch_assoc()): ?>
<div class="box">
    <h3><?php echo htmlspecialchars($ann['Title']); ?></h3>
    <p><?php echo nl2br(htmlspecialchars($ann['Content'])); ?></p>
    <small>
        Status: 
        <?php 
        if ($ann['status'] == 'pending') echo '<span class="status-pending">Pending (Waiting for Admin Approval)</span>';
        elseif ($ann['status'] == 'approved') echo '<span class="status-approved">Approved</span>';
        else echo '<span class="status-rejected">Rejected</span>';
        ?>
        | Date: <?php echo $ann['DatePosted']; ?>
    </small>

    <!-- DELETE ANNOUNCEMENT -->
    <form method="POST" style="display:inline;">
        <input type="hidden" name="announcement_id" value="<?php echo $ann['announcement_id']; ?>">
        <button class="delete" name="delete_announcement" onclick="return confirm('Delete this announcement and all its feedback?')">Delete Announcement</button>
    </form>

    <!-- FETCH FEEDBACKS -->
    <?php
    $feedbacks = $conn->query("
        SELECT f.*, u.firstname, u.middlename, u.lastname
        FROM agriculture_announcement_feedback f
        LEFT JOIN user u ON f.user_email=u.email
        WHERE f.announcement_id={$ann['announcement_id']}
        ORDER BY f.feedback_id DESC
    ");
    while ($fb = $feedbacks->fetch_assoc()):
        $studentName = trim(($fb['firstname'] ?? '') . ' ' . ($fb['middlename'] ?? '') . ' ' . ($fb['lastname'] ?? ''));
        if (empty($studentName)) $studentName = $fb['user_email'];
    ?>
    <div class="feedback-box">
        <b><?php echo htmlspecialchars($studentName); ?></b><br>
        <?php echo nl2br(htmlspecialchars($fb['feedback_text'])); ?><br>
        <small>Sent: <?php echo $fb['date_sent']; ?></small><br>

        <!-- FACULTY REPLY FORM -->
        <form method="POST" style="margin-top:5px;">
            <input type="hidden" name="feedback_id" value="<?php echo $fb['feedback_id']; ?>">
            <textarea name="reply_text" required placeholder="Write a reply..."></textarea><br>
            <button class="reply" name="reply_feedback">Reply</button>
        </form>

        <!-- DISPLAY REPLIES -->
        <?php
        $replies = $conn->query("
            SELECT r.*, u.firstname, u.lastname
            FROM agriculture_feedback_replies r
            LEFT JOIN user u ON r.faculty_id = u.id
            WHERE r.feedback_id={$fb['feedback_id']}
            ORDER BY r.date_sent ASC
        ");

        while ($rep = $replies->fetch_assoc()):
            $facultyNameReply = trim(($rep['firstname'] ?? '') . ' ' . ($rep['lastname'] ?? ''));
        ?>
        <div class="reply-box">
            <b><?php echo htmlspecialchars($facultyNameReply ?: 'Your Reply:'); ?></b><br>
            <?php echo nl2br(htmlspecialchars($rep['reply_text'])); ?><br>
            <small>Replied: <?php echo $rep['date_sent']; ?></small>

            <?php if ($rep['faculty_id'] == $facultyId): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="reply_id" value="<?php echo $rep['reply_id']; ?>">
                    <button class="delete" name="delete_reply" onclick="return confirm('Delete your reply?')">Delete Reply</button>
                </form>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>

    </div>
    <?php endwhile; ?>

</div>
<?php endwhile; ?>

</div>

<script>
// LOGOUT BUTTON
document.getElementById("logoutBtn").addEventListener("click", function() {
    if (confirm("Are you sure you want to log out?")) {
        fetch('/logout.php').then(() => {
            window.location.href = "/login/faculty_login.php";
        });
    }
});

// PREVENT BACK BUTTON
(function () {
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
})();
</script>

</body>
</html>
