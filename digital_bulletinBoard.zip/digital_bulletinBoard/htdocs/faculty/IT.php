<?php
session_start();

// ============================
// REQUIRE LOGIN
// ============================
if (!isset($_SESSION['email'])) {
    http_response_code(404);
    echo "<h1>404 Not Found</h1><p>This page is not accessible.</p>";
    exit();
}

// ============================
// ANTI-CACHE HEADERS
// ============================
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// ============================
// DATABASE CONNECTION
// ============================
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ============================
// FETCH FACULTY PROFILE
// ============================
$faculty_email = $_SESSION['email'];
$facultyPic = '/default_profile.png';
$facultyName = '';
$facultyId = 0;

$stmt = $conn->prepare("SELECT id, firstname, lastname, profile_image FROM user WHERE email=?");
$stmt->bind_param("s", $faculty_email);
$stmt->execute();
$faculty = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($faculty) {
    $facultyId = $faculty['id'];
    $facultyName = $faculty['firstname'] . " " . $faculty['lastname'];
    $facultyPic = !empty($faculty['profile_image']) ? "/uploads/" . $faculty['profile_image'] : "/default_profile.png";
}

// ============================
// CREATE ANNOUNCEMENT
// ============================
if (isset($_POST['create_announcement'])) {
    $title = $_POST['title'];
    $content = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO it_announcement (Title, Content, status, DatePosted) VALUES (?, ?, 'pending', NOW())");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    $stmt->close();

    header("Location: IT.php");
    exit();
}

// ============================
// DELETE ANNOUNCEMENT
// ============================
if (isset($_POST['delete_announcement'])) {
    $announcement_id = intval($_POST['announcement_id']);

    $stmt = $conn->prepare("
        DELETE r FROM it_feedback_replies r
        JOIN it_announcement_feedback f ON r.feedback_id = f.feedback_id
        WHERE f.announcement_id = ?
    ");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM it_announcement_feedback WHERE announcement_id = ?");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM it_announcement WHERE announcement_id = ?");
    $stmt->bind_param("i", $announcement_id);
    $stmt->execute();
    $stmt->close();

    header("Location: IT.php");
    exit();
}

// ============================
// DELETE REPLY
// ============================
if (isset($_POST['delete_reply'])) {
    $reply_id = intval($_POST['reply_id']);

    $stmt = $conn->prepare("DELETE FROM it_feedback_replies WHERE reply_id = ? AND faculty_id = ?");
    $stmt->bind_param("ii", $reply_id, $facultyId);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// ============================
// ADD REPLY
// ============================
if (isset($_POST['reply_feedback'])) {
    $feedback_id = intval($_POST['feedback_id']);
    $reply_text = $_POST['reply_text'];
    $date = date("Y-m-d H:i:s");

    $stmt2 = $conn->prepare("SELECT announcement_id FROM it_announcement_feedback WHERE feedback_id=?");
    $stmt2->bind_param("i", $feedback_id);
    $stmt2->execute();
    $result = $stmt2->get_result()->fetch_assoc();
    $announcement_id = $result['announcement_id'];
    $stmt2->close();

    $stmt = $conn->prepare("
        INSERT INTO it_feedback_replies 
        (announcement_id, feedback_id, faculty_id, reply_text, date_sent) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("iiiss", $announcement_id, $feedback_id, $facultyId, $reply_text, $date);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// ============================
// FETCH ANNOUNCEMENTS
// ============================
$announcements = $conn->query("SELECT * FROM it_announcement ORDER BY announcement_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>IT Faculty Dashboard</title>

<style>
/* ========== GLOBAL ========== */
body {
    font-family: Arial, sans-serif;
    background: #efebe9;
    margin: 0;
    padding: 0;
    animation: fadeIn 0.6s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ========== HEADER ========== */
header {
    background: #4e342e;
    color: white;
    text-align: center;
    padding: 20px;
    font-size: 26px;
    font-weight: bold;
    position: relative;
    animation: slideDown 0.6s ease;
    box-shadow: 0 3px 8px rgba(0,0,0,0.35);
}

@keyframes slideDown {
    from { opacity: 0; transform: translateY(-15px); }
    to { opacity: 1; transform: translateY(0); }
}

#logoutBtn {
    position: absolute;
    right: 15px;
    top: 15px;
    padding: 8px 12px;
    background: #795548;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: 0.2s ease;
}
#logoutBtn:hover {
    background: #a1887f;
    transform: scale(1.08);
}

/* ========== CONTAINER ========== */
.container {
    max-width: 900px;
    margin: 20px auto;
}

/* ========== BOXES ========== */
.box {
    background: #ffffff;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 3px 8px rgba(121,85,72,0.25);
    animation: fadeInUp 0.55s ease;
    transition: 0.2s ease-in-out;
}

.box:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(121,85,72,0.35);
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(15px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ========== FEEDBACK & REPLIES ========== */
.feedback-box {
    background: #efebe9;
    padding: 12px;
    border-radius: 8px;
    margin-top: 10px;
}

.reply-box {
    background: #d7ccc8;
    padding: 10px;
    border-radius: 6px;
    margin-top: 6px;
    margin-left: 20px;
}

/* ========== FORMS ========== */
textarea, input[type="text"] {
    width: 100%;
    padding: 8px;
    border-radius: 6px;
    border: 1px solid #a1887f;
    margin-bottom: 10px;
}
textarea:focus, input[type="text"]:focus {
    border-color: #6d4c41;
    box-shadow: 0 0 5px rgba(109,76,65,0.6);
}

/* ========== BUTTONS ========== */
button {
    padding: 7px 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button.delete {
    background: #6d4c41;
    color: white;
}
button.delete:hover {
    background: #8d6e63;
}

button.reply {
    background: #4e342e;
    color: white;
}
button.reply:hover {
    background: #6d4c41;
}

/* ========== STATUS COLORS ========== */
.status-pending { color: #ff8f00; font-weight: bold; }
.status-approved { color: #2e7d32; font-weight: bold; }
.status-rejected { color: #c62828; font-weight: bold; }
</style>

</head>
<body>

<header>
    INDUSTRIAL TECHNOLOGY Faculty Dashboard
    <button id="logoutBtn">Logout</button>
</header>

<div class="container">

<!-- CREATE ANNOUNCEMENT -->
<div class="box">
    <h2>Create Announcement</h2>
    <form method="POST">
        <label>Title:</label>
        <input type="text" name="title" required>

        <label>Content:</label>
        <textarea name="message" required></textarea>

        <button type="submit" name="create_announcement" class="reply">Post Announcement</button>
    </form>
</div>

<!-- DISPLAY ANNOUNCEMENTS -->
<?php while ($ann = $announcements->fetch_assoc()): ?>
<div class="box">
    <h3><?php echo htmlspecialchars($ann['Title']); ?></h3>
    <p><?php echo nl2br(htmlspecialchars($ann['Content'])); ?></p>

    <small>
        Status: 
        <?php 
        if ($ann['status'] == 'pending') echo '<span class="status-pending">Pending (Waiting for Admin Approval)</span>';
        elseif ($ann['status'] == 'approved') echo '<span class="status-approved">Approved</span>';
        else echo '<span class="status-rejected">Rejected</span>';
        ?>
        | Date: <?php echo $ann['DatePosted']; ?>
    </small>

    <form method="POST">
        <input type="hidden" name="announcement_id" value="<?php echo $ann['announcement_id']; ?>">
        <button class="delete" name="delete_announcement">Delete Announcement</button>
    </form>

    <!-- FEEDBACKS -->
    <?php
    // UPDATED QUERY: fetch student's first and last name
    $feedbacks = $conn->query("
        SELECT f.*, u.firstname, u.lastname
        FROM it_announcement_feedback f
        LEFT JOIN user u ON f.user_email = u.email
        WHERE f.announcement_id = {$ann['announcement_id']}
        ORDER BY f.feedback_id DESC
    ");

    while ($fb = $feedbacks->fetch_assoc()):
    ?>
    <div class="feedback-box">
        <b>
        <?php 
            echo !empty($fb['firstname']) 
                ? htmlspecialchars($fb['firstname'] . " " . $fb['lastname'])
                : htmlspecialchars($fb['user_email']);
        ?>
        </b><br>

        <?php echo nl2br(htmlspecialchars($fb['feedback_text'])); ?><br>
        <small>Sent: <?php echo $fb['date_sent']; ?></small>

        <form method="POST" style="margin-top:5px;">
            <input type="hidden" name="feedback_id" value="<?php echo $fb['feedback_id']; ?>">
            <textarea name="reply_text" required placeholder="Write a reply..."></textarea>
            <button class="reply" name="reply_feedback">Reply</button>
        </form>

        <!-- REPLIES -->
        <?php
        $replies = $conn->query("SELECT * FROM it_feedback_replies WHERE feedback_id={$fb['feedback_id']} ORDER BY date_sent ASC");
        while ($rep = $replies->fetch_assoc()):
        ?>
        <div class="reply-box">
            <b>Your Reply:</b><br>
            <?php echo nl2br(htmlspecialchars($rep['reply_text'])); ?><br>
            <small>Replied: <?php echo $rep['date_sent']; ?></small>

            <?php if ($rep['faculty_id'] == $facultyId): ?>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="reply_id" value="<?php echo $rep['reply_id']; ?>">
                <button class="delete" name="delete_reply">Delete Reply</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>

    </div>
    <?php endwhile; ?>

</div>
<?php endwhile; ?>

</div>

<script>
// LOGOUT
document.getElementById("logoutBtn").addEventListener("click", function() {
    if (confirm("Are you sure you want to log out?")) {
        fetch('/logout.php').then(() => {
            window.location.href = "/login/faculty_login.php";
        });
    }
});

// PREVENT BACK BUTTON
(function () {
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
})();
</script>

</body>
</html>
