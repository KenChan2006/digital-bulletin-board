<?php
session_start();

// --- CHECK LOGIN AND ROLE ---
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

// --- DB CONNECTION ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// --- FETCH USER INFO ---
$sql = "SELECT id, firstname, middlename, lastname, email, role, profile_image 
        FROM user
        WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

$user_id = $user['id'];

$fullName = trim($user['firstname'] . " " . $user['middlename'] . " " . $user['lastname']);

$profilePic = !empty($user['profile_image'])
    ? "uploads/" . $user['profile_image'] . "?t=" . time()
    : "default_profile.png";

// --- HANDLE PROFILE UPLOAD ---
$uploadError = '';
if (isset($_POST['upload_pic'])) {
    if (!empty($_FILES['profileUpload']['name'])) {

        $imgName = $_FILES['profileUpload']['name'];
        $tmpName = $_FILES['profileUpload']['tmp_name'];
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $ext = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));

        if (in_array($ext, $allowed)) {

            $newName = "admin_" . $user_id . "_" . time() . "." . $ext;
            $uploadDir = "uploads/";

            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $uploadPath = $uploadDir . $newName;

            if (move_uploaded_file($tmpName, $uploadPath)) {

                $update = $conn->prepare("UPDATE user SET profile_image=? WHERE email=?");
                $update->bind_param("ss", $newName, $email);

                if ($update->execute()) {
                    header("Location: profile.php?uploaded=1");
                    exit();
                } else {
                    $uploadError = "Failed to update database.";
                }
            } else {
                $uploadError = "Failed to upload file.";
            }
        } else {
            $uploadError = "Invalid file type. Allowed: jpg, jpeg, png, gif.";
        }
    } else {
        $uploadError = "No file selected.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="/digitalDesign/studentcss/profile.css">

    <style>
        /* Extra styling for admin */
        header.account-header h1 {
            color: #2575fc;
        }
        .save-btn {
            background: #2575fc;
        }
        .update-btn {
            background: #e63946;
        }
    </style>
</head>

<body>

<a href="admin_home.php" class="back-btn">⬅ BACK</a>

<header class="account-header fade-in">
    <h1>Admin Profile</h1>
    <p>Manage your account information.</p>
</header>

<?php
if (!empty($uploadError)) {
    echo "<p class='error-msg'>$uploadError</p>";
} elseif (isset($_GET['uploaded'])) {
    echo "<p class='success-msg'>Profile picture updated successfully!</p>";
}
?>

<section class="profile-section slide-up">
    <div class="profile-picture">
        <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" id="profileImage">

        <form method="POST" enctype="multipart/form-data">
            <label class="upload-btn">
                Choose Picture
                <input type="file" id="profileUpload" name="profileUpload" accept="image/*" required>
            </label>

            <button class="save-btn" name="upload_pic" type="submit">Upload New Picture</button>
        </form>
    </div>

    <div class="profile-details">
        <form>

            <label>Name:</label>
            <input type="text" value="<?php echo htmlspecialchars($fullName); ?>" disabled>

            <label>Email:</label>
            <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>

            <label>Role:</label>
            <input type="text" value="<?php echo htmlspecialchars($user['role']); ?>" disabled>

            <button onclick="window.location.href='/login/admin_login.php'" type="button" class="update-btn" style="margin-top:20px;">
                Logout
            </button>

        </form>
    </div>
</section>

</body>
</html>
