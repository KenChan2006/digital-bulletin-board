<?php
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch only AGRICULTURE students directly from studentuser
$query = "
    SELECT user_id, first_name, middle_name, last_name, school_ID, email, college
    FROM studentuser
    WHERE UPPER(college) LIKE '%AGRICULTURE%'
";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>College of Agriculture - Users</title>
<style>
body {
    font-family: Poppins, sans-serif;
    background: linear-gradient(135deg, #004aad, #007bff);
    color: white;
    margin: 0;
    padding: 0;
    animation: fadeIn 1s ease-in-out;
}
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

h1 { text-align: center; margin-top: 30px; font-size: 38px; animation: slideDown 0.6s ease-out;}
@keyframes slideDown { from { transform: translateY(-30px); opacity:0;} to { transform: translateY(0); opacity:1;} }

.back-btn {
    position: absolute; top: 20px; left: 20px;
    padding: 10px 18px; background: rgba(255,255,255,0.2);
    color:white; border-radius:8px; text-decoration:none;
    backdrop-filter: blur(6px); transition:0.3s;
}
.back-btn:hover { background: rgba(255,255,255,0.4); }

.search-bar { width:80%; margin:20px auto; display:flex; justify-content:center; gap:10px;}
.search-bar input { width:60%; padding:12px; border-radius:8px; border:none; font-size:16px; outline:none;}
.search-bar button { padding:12px 20px; border:none; border-radius:8px; background:#ffd60a; color:black; font-weight:bold; cursor:pointer;}
table { width:90%; margin:20px auto; border-collapse:collapse; background:white; color:black; border-radius:12px; overflow:hidden;}
th { background:#003566; color:white; padding:14px; }
td { padding:12px; text-align:center; border-bottom:1px solid #ddd; }
tr:hover { background:#e3f2ff; transform:scale(1.01);}
</style>
</head>
<body>

<a href="info.php" class="back-btn">⬅ BACK</a>
<h1>College of Agriculture - Users</h1>

<div class="search-bar">
    <input type="text" id="searchInput" placeholder="Search users..." onkeyup="searchUsers()">
    <button onclick="searchUsers()">Search</button>
</div>

<table id="userTable">
    <thead>
        <tr>
            <th>User ID</th>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Last Name</th>
            <th>School ID</th>
            <th>Email</th>
            <th>College</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".htmlspecialchars($row['user_id'])."</td>";
                echo "<td>".htmlspecialchars($row['first_name'])."</td>";
                echo "<td>".htmlspecialchars($row['middle_name'])."</td>";
                echo "<td>".htmlspecialchars($row['last_name'])."</td>";
                echo "<td>".htmlspecialchars($row['school_ID'])."</td>";
                echo "<td>".htmlspecialchars($row['email'])."</td>";
                echo "<td>".htmlspecialchars($row['college'])."</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No AGRICULTURE users found.</td></tr>";
        }
        ?>
    </tbody>
</table>

<script>
function searchUsers() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let table = document.getElementById("userTable");
    let rows = table.getElementsByTagName("tr");
    for (let i = 1; i < rows.length; i++) {
        let cells = rows[i].getElementsByTagName("td");
        let match = false;
        for (let j = 0; j < cells.length; j++) {
            if (cells[j].innerText.toLowerCase().includes(input)) { match=true; break; }
        }
        rows[i].style.display = match ? "" : "none";
    }
}
</script>

</body>
</html>
