<?php
session_start();

// --- CHECK ADMIN LOGIN ---
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

// --- DB CONNECTION ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

/* -----------------------------------------
   APPROVE ANNOUNCEMENT (EDUC + CAS + IT + ENG + AGRICULTURE)
----------------------------------------- */
if (isset($_GET['approve']) && isset($_GET['table'])) {
    $id = intval($_GET['approve']);
    $table = $_GET['table'];  

    if ($table === "educ") {
        $conn->query("UPDATE educ_announcement SET status='approved' WHERE announcement_id=$id");
    } 
    else if ($table === "cas") {
        $conn->query("UPDATE cas_announcement SET status='approved' WHERE announcement_id=$id");
    }
    else if ($table === "it") {
        $conn->query("UPDATE it_announcement SET status='approved' WHERE announcement_id=$id");
    }
    else if ($table === "eng") {
        $conn->query("UPDATE eng_announcement SET status='approved' WHERE announcement_id=$id");
    }
    else if ($table === "agriculture") {
        $conn->query("UPDATE agriculture_announcement SET status='approved' WHERE announcement_id=$id");
    }

    header("Location: announcement.php");
    exit();
}

/* -----------------------------------------
   REJECT ANNOUNCEMENT (EDUC + CAS + IT + ENG + AGRICULTURE)
----------------------------------------- */
if (isset($_GET['reject']) && isset($_GET['table'])) {
    $id = intval($_GET['reject']);
    $table = $_GET['table'];

    if ($table === "educ") {
        $conn->query("UPDATE educ_announcement SET status='rejected' WHERE announcement_id=$id");
    } 
    else if ($table === "cas") {
        $conn->query("UPDATE cas_announcement SET status='rejected' WHERE announcement_id=$id");
    }
    else if ($table === "it") {
        $conn->query("UPDATE it_announcement SET status='rejected' WHERE announcement_id=$id");
    }
    else if ($table === "eng") {
        $conn->query("UPDATE eng_announcement SET status='rejected' WHERE announcement_id=$id");
    }
    else if ($table === "agriculture") {
        $conn->query("UPDATE agriculture_announcement SET status='rejected' WHERE announcement_id=$id");
    }

    header("Location: announcement.php");
    exit();
}

/* -----------------------------------------
   FETCH PENDING ANNOUNCEMENTS (EDUC + CAS + IT + ENG + AGRICULTURE)
----------------------------------------- */
$educ_query = "SELECT announcement_id, Title, Content, DatePosted, 'educ' AS source 
               FROM educ_announcement 
               WHERE status='pending'";

$cas_query = "SELECT announcement_id, Title, Content, Date_Posted AS DatePosted, 'cas' AS source 
              FROM cas_announcement
              WHERE status='pending'";

$it_query = "SELECT announcement_id, Title, Content, DatePosted, 'it' AS source 
             FROM it_announcement
             WHERE status='pending'";

$eng_query = "SELECT announcement_id, Title, Content, DatePosted, 'eng' AS source
              FROM eng_announcement
              WHERE status='pending'";

$agri_query = "SELECT announcement_id, Title, Content, DatePosted, 'agriculture' AS source
               FROM agriculture_announcement
               WHERE status='pending'";

$sql = "$educ_query UNION $cas_query UNION $it_query UNION $eng_query UNION $agri_query ORDER BY DatePosted ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Announcement Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* { margin:0; padding:0; box-sizing:border-box; }

body {
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    padding: 20px;
}

.back-btn {
    display: inline-block;
    padding: 10px 15px;
    background: #2b2b2b;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    margin-bottom: 20px;
    transition: 0.3s;
}
.back-btn:hover { background: #444; }

h1 { text-align:center; margin-bottom: 25px; color: #1f3c88; }

.table-container { width: 100%; overflow-x: auto; }

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

th, td { padding: 12px; border-bottom: 1px solid #ddd; }
th { background: #1f3c88; color:white; }
tr:nth-child(even) { background: #f0f2f5; }

.btn-approve { background: #28a745; color:white; padding:6px 12px; border-radius:5px; text-decoration:none; }
.btn-reject { background: #dc3545; color:white; padding:6px 12px; border-radius:5px; text-decoration:none; }
.btn-approve:hover { background: #218838; }
.btn-reject:hover { background: #c82333; }

/* 🔥 ONLY CHANGE YOU REQUESTED — STACK BUTTONS VERTICALLY */
.action-buttons {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.action-buttons a {
    display: block;
    width: 100%;
    text-align: center;
}

td.content-box { max-width: 350px; white-space: normal; word-wrap: break-word; }
td.pending-days { text-align:center; }
</style>
</head>
<body>

<a href="info.php" class="back-btn">⬅ Back</a>
<h1>Pending Announcements</h1>

<div class="table-container">
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Source</th>
            <th>Title</th>
            <th>Content</th>
            <th>Date Posted</th>
            <th>Pending Days</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
<?php
if ($result->num_rows > 0) {
    $today = new DateTime();
    while ($row = $result->fetch_assoc()) {
        $source_label = strtoupper($row['source']);
        $datePosted = new DateTime($row['DatePosted']);
        $pendingDays = $today->diff($datePosted)->days;

        echo "<tr>";
        echo "<td>".$row['announcement_id']."</td>";
        echo "<td>".$source_label."</td>";
        echo "<td>".$row['Title']."</td>";
        echo "<td class='content-box'>".$row['Content']."</td>";
        echo "<td>".$row['DatePosted']."</td>";
        echo "<td class='pending-days'>".$pendingDays."</td>";

        // 🔥 UPDATED BUTTON LAYOUT (VERTICAL)
        echo "<td>
                <div class='action-buttons'>
                    <a class='btn-approve' href='announcement.php?approve=".$row['announcement_id']."&table=".$row['source']."'>Approve</a>
                    <a class='btn-reject' href='announcement.php?reject=".$row['announcement_id']."&table=".$row['source']."'>Reject</a>
                </div>
              </td>";

        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7' style='text-align:center;'>No pending announcements</td></tr>";
}
?>
    </tbody>
</table>
</div>

</body>
</html>
