<?php
/* =========================================================
   ADMIN DASHBOARD - Persistent Session, Announcement Post
   ========================================================= */

// --- SESSION CONFIGURATION: 8 HOURS ---
session_set_cookie_params([
    'lifetime' => 28800, // 8 hours
    'path' => '/',
    'secure' => false,   // set to true kung HTTPS
    'httponly' => true,
    'samesite' => 'Strict'
]);
session_start();

// --- ADMIN LOGIN VALIDATION ---
if (!isset($_SESSION['email']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo "<h2 style='color:red; text-align:center; margin-top:40px;'>ACCESS DENIED: Admin Only</h2>";
    exit();
}

// --- RESET LAST ACTIVITY ---
$_SESSION['last_activity'] = time();

// --- DATABASE CONNECTION ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// --- FETCH ADMIN PROFILE ---
$admin_email = $_SESSION['email'];
$stmt = $conn->prepare("
    SELECT firstname, lastname, profile_image 
    FROM user 
    WHERE email = ?
");
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

$adminName = $admin ? $admin['firstname'] . " " . $admin['lastname'] : "Administrator";
$adminPic = (!empty($admin['profile_image'])) 
    ? "/uploads/" . $admin['profile_image'] . "?t=" . time()
    : "/default_profile.png";

// --- POST NEW ANNOUNCEMENT ---
if (isset($_POST['post_announcement'])) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $date_posted = date("Y-m-d H:i:s");

    if ($title && $content) {
        $stmt = $conn->prepare("
            INSERT INTO admin_announcement
            (Title, Content, `Date Posted`)
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("sss", $title, $content, $date_posted);
        if ($stmt->execute()) {

            // --- SEND EMAIL TO ALL STUDENTS ---
            $result = $conn->query("SELECT email FROM studentuser");
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $studentEmail = $row['email'];
                    $subject = "New Announcement: $title";
                    $message = "Hello,\n\nA new announcement has been posted:\n\n$title\n\n$content\n\nBest Regards,\nDigital Bulletin Board";
                    $headers = "From: admin@digitalbulletinboard.com\r\n";
                    @mail($studentEmail, $subject, $message, $headers);
                }
            }

            $_SESSION['post_message'] = [
                'type' => 'success',
                'text' => 'Announcement posted successfully!'
            ];
        } else {
            $_SESSION['post_message'] = [
                'type' => 'error',
                'text' => 'Failed to post announcement.'
            ];
        }
        $stmt->close();
    } else {
        $_SESSION['post_message'] = [
            'type' => 'error',
            'text' => 'Please fill in both Title and Content.'
        ];
    }

    header("Location: admin_home.php");
    exit();
}

// --- FETCH ALL ANNOUNCEMENTS ---
$announcements = [];
$result = $conn->query("SELECT * FROM admin_announcement ORDER BY `Date Posted` DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $announcements[] = $row;
    }
}

// --- DISPLAY MESSAGE IF ANY ---
$displayMessage = null;
if (isset($_SESSION['post_message'])) {
    $displayMessage = $_SESSION['post_message'];
    unset($_SESSION['post_message']);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Homepage</title>
<style>
body, html { margin: 0; font-family: Arial, sans-serif; background: #f3f4f7; }

/* HEADER */
.admin-header {
    background: linear-gradient(135deg, #1f3c88, #4a62b3);
    color: white;
    text-align: center;
    padding: 60px 20px;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    position: relative;
}
.admin-header h1 { margin: 0; font-size: 36px; }
.admin-header h2 { margin-top: 8px; font-weight: 400; opacity: 0.9; }

.admin-nav {
    display: flex;
    justify-content: center;
    margin: 30px 0;
}
.nav-btn {
    background: #244d9a;
    color: white;
    border: none;
    padding: 14px 24px;
    border-radius: 10px;
    cursor: pointer;
    transition: 0.3s;
}
.nav-btn:hover { background: #193b75; transform: scale(1.05); }

.section-title { text-align: center; margin-top: 20px; }
.section-title h2 {
    font-size: 28px;
    color: #333;
    border-bottom: 3px solid #1f3c88;
    display: inline-block;
    padding-bottom: 6px;
}

.announcement-form {
    max-width: 600px;
    margin: 20px auto;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.form-input {
    padding: 14px;
    border-radius: 10px;
    border: 1px solid #ccc;
    font-size: 16px;
    width: 100%;
}
.form-input:focus {
    border-color: #1f3c88;
    box-shadow: 0 0 8px rgba(31,60,136,0.2);
}

.post-btn {
    background: #1f3c88;
    color: white;
    border: none;
    padding: 14px;
    border-radius: 10px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}
.post-btn:hover { background: #163166; transform: scale(1.03); }

.success-msg { color: #28a745; text-align: center; }
.error-msg { color: #dc3545; text-align: center; }

.announcement-container {
    max-width: 900px;
    margin: 20px auto;
}

.announcement-card {
    background: white;
    padding: 22px;
    border-radius: 14px;
    margin-bottom: 20px;
    border-left: 6px solid #1f3c88;
    box-shadow: 0 6px 18px rgba(0,0,0,0.08);
}
</style>
</head>
<body>

<header class="admin-header">
    <h1>ADMIN DASHBOARD</h1>
    <h2>Welcome, <?php echo htmlspecialchars($adminName); ?></h2>
</header>

<div class="admin-nav">
    <button class="nav-btn" onclick="location.href='info.php'">👥 View All Information</button>
    <!-- Logout button removed -->
</div>

<section class="section-title">
    <h2>Post New Announcement</h2>
    <?php
    if ($displayMessage) {
        $class = ($displayMessage['type'] === 'success') ? 'success-msg' : 'error-msg';
        echo "<p class='$class'>" . htmlspecialchars($displayMessage['text']) . "</p>";
    }
    ?>
</section>

<form method="POST" class="announcement-form">
    <input type="text" name="title" placeholder="Announcement Title" required class="form-input">
    <textarea name="content" placeholder="Announcement Content" rows="4" required class="form-input"></textarea>
    <button type="submit" name="post_announcement" class="post-btn">Post Announcement</button>
</form>

<section class="section-title">
    <h2>Posted Announcements</h2>
</section>

<main id="announcement-container" class="announcement-container"></main>

<script>
const announcements = <?php echo json_encode($announcements); ?>;
const container = document.getElementById('announcement-container');

function renderAnnouncements() {
    container.innerHTML = '';
    announcements.forEach(item => {
        const card = document.createElement('div');
        card.classList.add('announcement-card');
        card.innerHTML = `
            <h3>${item.Title}</h3>
            <p>${item.Content}</p>
            <small>Posted on: ${new Date(item['Date Posted']).toLocaleString()}</small>
        `;
        container.appendChild(card);
    });
}

renderAnnouncements();

// Optional: Auto-refresh announcements every 5 minutes
setInterval(() => {
    location.reload();
}, 300000); // 5 minutes
</script>

</body>
</html>
