<?php
session_start();

// --- CHECK ADMIN LOGIN ---
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

// --- DB CONNECTION ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH FACULTY ONLY ---
$sql = "SELECT id, firstname, middlename, lastname, email, password 
        FROM user
        WHERE role = 'faculty'";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Faculty Information</title>

  <style>
    /* RESET */ 
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f4f6f9;
      color: #333;
      padding: 20px;
    }

    /* BACK BUTTON */
    .back-btn {
      display: inline-block;
      margin-bottom: 20px;
      padding: 10px 16px;
      background: #2b2b2b;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-size: 14px;
      transition: 0.3s;
    }
    .back-btn:hover { background: #444; }

    /* HEADER */
    h1 {
      text-align: center;
      margin-bottom: 30px;
      color: #1f3c88;
    }

    /* SEARCH BAR */
    .search-bar {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
      gap: 10px;
    }
    .search-bar input {
      width: 300px;
      padding: 10px;
      border: 1px solid #bbb;
      border-radius: 6px;
    }
    .search-bar button {
      padding: 10px 16px;
      border: none;
      background: #1f3c88;
      color: white;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.3s;
    }
    .search-bar button:hover { background: #4a6cf7; }

    /* TABLE */
    table {
      width: 100%;
      border-collapse: collapse;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      border-radius: 10px;
      overflow: hidden;
      animation: fadeIn 0.5s ease;
    }

    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background: #1f3c88;
      color: white;
      position: sticky;
      top: 0;
    }

    tr:nth-child(even) { background: #f0f2f5; }

    tr:hover { background: #dbe4f7; transition: 0.3s; }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>

</head>
<body>

  <!-- BACK BUTTON -->
  <a href="info.php" class="back-btn">⬅ BACK</a>

  <!-- HEADER -->
  <h1>Faculty Information</h1>

  <!-- SEARCH BAR -->
  <div class="search-bar">
    <input type="text" id="searchInput" placeholder="Search faculty..." onkeyup="searchFaculty()">
    <button onclick="searchFaculty()">Search</button>
  </div>

  <!-- FACULTY TABLE -->
  <table id="facultyTable">
    <thead>
      <tr>
        <th>Faculty ID</th>
        <th>First Name</th>
        <th>Middle Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Password</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td>" . htmlspecialchars($row['id']) . "</td>";
              echo "<td>" . htmlspecialchars($row['firstname']) . "</td>";
              echo "<td>" . htmlspecialchars($row['middlename']) . "</td>";
              echo "<td>" . htmlspecialchars($row['lastname']) . "</td>";
              echo "<td>" . htmlspecialchars($row['email']) . "</td>";
              echo "<td>" . htmlspecialchars($row['password']) . "</td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td colspan='6'>No faculty found</td></tr>";
      }
      ?>
    </tbody>
  </table>

<script>
  function searchFaculty() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("#facultyTable tbody tr");

    rows.forEach(row => {
      let text = row.textContent.toLowerCase();
      row.style.display = text.includes(input) ? "" : "none";
    });
  }
</script>

</body>
</html>
