<?php
$host = 'localhost'; 
$dbname = 'digital_bulletin_board'; 
$username = 'root'; 
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql_users = "SELECT * FROM user WHERE role IN ('admin')";
$result_users = $conn->query($sql_users);

if ($result_users->num_rows > 0) {
    $users = [];
    while ($row = $result_users->fetch_assoc()) {
        $users[] = $row; 
    }
} else {
    $users = [];
}

$sql_announcements = "SELECT * FROM admin_announcement";
$result_announcements = $conn->query($sql_announcements);

if ($result_announcements->num_rows > 0) {
    $announcements = [];
    while ($row = $result_announcements->fetch_assoc()) {
        $announcements[] = $row; 
    }
} else {
    $announcements = [];
}

// Handle Deletion of Announcement
if (isset($_GET['delete_id'])) {
    $announcement_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM admin_announcement WHERE announcement_id = $announcement_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Announcement deleted successfully.'); window.location.href = 'info.php';</script>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Information - Admin</title>

  <!-- ANTI-BACK AND CACHE PREVENTION -->
  <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f4f6f9;
      color: #333;
    }

    .section-title {
      text-align: center;
    }

    /* BACK BUTTON */
    .back-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      padding: 10px 16px;
      background: #2b2b2b;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-size: 14px;
      z-index: 100;
      transition: 0.3s;
    }

    .back-btn:hover {
      background: #444;
    }

    /* LOGOUT BUTTON */
    .logout-btn {
        position: fixed;
        top: 15px;
        right: 15px;
        padding: 10px 16px;
        background: #d9534f;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        cursor: pointer;
        z-index: 100;
        transition: 0.3s;
    }

    .logout-btn:hover {
        background: #b8433f;
    }

    /* HEADER */
    .user-header {
      text-align: center;
      padding: 50px 20px;
      background: linear-gradient(135deg, #4a6cf7, #1f3c88);
      color: white;
      border-bottom-left-radius: 20px;
      border-bottom-right-radius: 20px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    .user-header h1 {
      font-size: 36px;
    }

    /* FILTER BUTTONS */
    .filter-section {
      margin: 20px auto;
      width: 90%;
      max-width: 1000px;
      text-align: center;
    }

    .filter-buttons button,
    .college-filters button {
      padding: 10px 16px;
      margin: 5px;
      border: none;
      background: #1f3c88;
      color: white;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .filter-buttons button:hover,
    .college-filters button:hover {
      background: #4a6cf7;
      transform: scale(1.05);
    }

    /* USER TABLE */
    .user-table {
      width: 90%;
      max-width: 1000px;
      margin: 20px auto;
      border-collapse: collapse;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .user-table th {
      background: #1f3c88;
      color: white;
      padding: 14px;
      font-size: 16px;
    }

    .user-table td {
      padding: 12px;
      border-bottom: 1px solid #ddd;
    }

    .user-table tr:nth-child(even) {
      background: #f0f2f5;
    }

    /* ANNOUNCEMENTS */
    .announcement-post {
      background: #fff;
      margin: 20px auto;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      width: 90%;
      max-width: 1000px;
    }

    .announcement-post h3 {
      font-size: 24px;
      margin-bottom: 10px;
    }

    .announcement-post p {
      font-size: 16px;
      line-height: 1.5;
      margin-bottom: 10px;
    }

    .announcement-post .date-posted {
      font-size: 14px;
      color: #888;
      margin-bottom: 20px;
    }

    .delete-btn {
      background: #d9534f;
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .delete-btn:hover {
      background: #b8433f;
      transform: scale(1.05);
    }
  </style>
</head>

<body>

  <a href="admin_home.php" class="back-btn">⬅ BACK</a>

  <!-- LOGOUT BUTTON -->
  <button class="logout-btn" id="logoutBtn">Log out</button>

  <header class="user-header">
    <h1>User & Announcement Management</h1>
  </header>

  <section class="filter-section">
    <h2 class="section-title">Filters</h2>
    <div class="filter-buttons">
      <button onclick="filterRole('all_user')">All Users</button>
      <button onclick="filterRole('faculty')">Faculty</button>
      <button onclick="filterRole('announcement')">Announcement</button>
    </div>
    <div class="college-filters">
      <button onclick="filterCollege('education')">Education</button>
      <button onclick="filterCollege('arts')">Arts & Sciences</button>
      <button onclick="filterCollege('engineering')">Engineering</button>
      <button onclick="filterCollege('industrial')">Industrial Tech</button>
      <button onclick="filterCollege('agriculture')">Agriculture</button>
    </div>
  </section>

  <section class="info-section">
    <h2 class="section-title">Admin Information</h2>
    <table class="user-table" id="userTable">
      <thead>
        <tr>
          <th>First Name</th>
          <th>Middle Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Role</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $user): ?>
          <tr>
            <td><?php echo htmlspecialchars($user['firstname']); ?></td>
            <td><?php echo htmlspecialchars($user['middlename']); ?></td>
            <td><?php echo htmlspecialchars($user['lastname']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td><?php echo htmlspecialchars($user['role']); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </section>

  <section class="announcement-section">
    <h2 class="section-title">Announcements</h2>
    <div id="announcementContainer">
      <?php foreach ($announcements as $announcement): ?>
        <div class="announcement-post">
          <h3><?php echo htmlspecialchars($announcement['Title']); ?></h3>
          <p><?php echo nl2br(htmlspecialchars($announcement['Content'])); ?></p>
          <p class="date-posted"><?php echo date('F j, Y', strtotime($announcement['Date Posted'])); ?></p>
          <a href="?delete_id=<?php echo $announcement['announcement_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this announcement?');">Delete</a>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <script>
    function filterRole(role) {
      if (role === 'all_user') {
        window.location.href = 'user_info.php'; 
      } else if (role === 'faculty') {
        window.location.href = 'faculty_info.php'; 
      } else if (role === 'announcement') {
        window.location.href = 'announcement.php'; 
      }
    }

    function filterCollege(college) {
      if (college === 'education'){
        window.location.href = 'educ_info.php';
      }
      else if (college === 'arts'){
        window.location.href = 'arts&sciences.php';
      }
      else if (college === 'engineering'){
        window.location.href = 'engineering.php';
      }
      else if (college === 'industrial'){
        window.location.href = 'IT_info.php';
      }
      else if (college === 'agriculture'){
        window.location.href = 'agri_info.php';
      }
    }
    
    // LOGOUT BUTTON
    document.getElementById('logoutBtn').addEventListener('click', () => {
        if (confirm('Are you sure you want to logout?')) {
            window.location.href = '/login/admin_login.php';
        }
    });

    // PREVENT BACK BUTTON
    window.history.forward();
    function noBack() { window.history.forward(); }
    window.onload = noBack;
    window.onpageshow = function(evt) { if (evt.persisted) noBack(); };
    window.onunload = function() {};
  </script>

</body>
</html>
