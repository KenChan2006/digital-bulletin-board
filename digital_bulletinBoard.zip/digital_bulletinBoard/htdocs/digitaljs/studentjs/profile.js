document.addEventListener("DOMContentLoaded", function () {
    const profileInput = document.getElementById("profileUpload");
    const profileImage = document.getElementById("profileImage");

    if (profileInput && profileImage) {
        profileInput.addEventListener("change", function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function() {
                    profileImage.src = reader.result;
                };
                reader.readAsDataURL(file);
            }
        });
    }
});
