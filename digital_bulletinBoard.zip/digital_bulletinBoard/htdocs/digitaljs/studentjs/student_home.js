document.addEventListener("DOMContentLoaded", () => {

    const modal = document.querySelector(".modal-overlay");
    const closeModal = document.getElementById("closeModal");

    document.querySelectorAll(".read-more-btn").forEach(btn => {
        btn.addEventListener("click", () => {

            const card = btn.closest(".info-card");
            const fullText = card.querySelector(".full-text").innerHTML;
            const shortText = card.querySelector(".short-text");

            // Expand text in card
            shortText.innerHTML = fullText;
            card.classList.add("expanded");
            btn.style.display = "none";

            // Modal
            document.getElementById("modal-title").innerText =
                card.querySelector("h3").innerText;

            document.getElementById("modal-content").innerHTML = fullText;

            modal.classList.add("show");
        });
    });

    // Close modal
    closeModal.addEventListener("click", () => modal.classList.remove("show"));
    modal.addEventListener("click", e => {
        if (e.target === modal) modal.classList.remove("show");
    });
});
