function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

function postAnnouncement(e) {
    e.preventDefault();

    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;
    const imageInput = document.getElementById("image");

    const announcementsContainer = document.getElementById("announcements-container");

    let imgTag = "";
    if (imageInput.files && imageInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            imgTag = `<img src="${e.target.result}" class="announcement-img">`;
            addCard();
        };
        reader.readAsDataURL(imageInput.files[0]);
    } else {
        addCard();
    }

    function addCard() {
        const date = new Date().toLocaleDateString();
        const card = document.createElement("div");
        card.className = "announcement-card";
        card.innerHTML = `
            <h3>${title}</h3>
            ${imgTag}
            <p>${content}</p>
            <span class="date">Posted: ${date}</span>
        `;
        announcementsContainer.prepend(card);
        document.getElementById("announcement-form").reset();
    }
}

function replyFeedback(button) {
    const feedbackCard = button.parentElement;
    const reply = feedbackCard.querySelector("textarea").value;
    if (reply.trim() === "") {
        alert("Reply cannot be empty!");
        return;
    }
    alert(`Reply sent: ${reply}`);
    feedbackCard.querySelector("textarea").value = "";
}
