// This handles the registration action and stores data in localStorage (optional)
function register() {
    let user = {
        firstname: document.getElementById("fn").value,
        middlename: document.getElementById("mn").value,
        lastname: document.getElementById("ln").value,
        email: document.getElementById("em").value,
        category: document.getElementById("op").value
    };

    localStorage.setItem("registeredUser", JSON.stringify(user));
}

// Allow PHP to submit form
document.getElementById("registerForm")?.addEventListener("submit", function(event) {
    register();  // Store user in localStorage (optional)
});
