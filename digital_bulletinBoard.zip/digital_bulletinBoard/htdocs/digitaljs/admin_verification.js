const defaultAdmin = {
    username: "@admin123",
    password: "password123"
};

// Add event listener to the "Verify" button
document.getElementById("verifyBtn").addEventListener("click", verifyAdmin);

function verifyAdmin(event) {
    event.preventDefault();  // Prevent the form from reloading the page

    let user = document.getElementById("adminUser").value.trim();
    let pass = document.getElementById("adminPass").value.trim();
    let errorMsg = document.getElementById("error");

    // Check if the input matches the default admin credentials
    if (user === defaultAdmin.username && pass === defaultAdmin.password) {
        errorMsg.style.color = "green";
        errorMsg.innerText = "Access Granted!";

        setTimeout(() => {
            // Redirect to the admin dashboard after success
            window.location.href = "../admin/admin_home.php";  // Redirect to admin dashboard
        }, 700);

    } else {
        errorMsg.style.color = "red";
        errorMsg.innerText = "Incorrect username or password!";
        errorMsg.classList.add("shake");

        // Remove shake animation after 500ms
        setTimeout(() => {
            errorMsg.classList.remove("shake");
        }, 500);
    }
}
