function verifyFaculty() {
    const user = document.getElementById("facultyUser").value.trim();
    const pass = document.getElementById("facultyPass").value.trim();
    const dept = document.getElementById("facultySelect").value;
    const errorBox = document.getElementById("error");

    const accounts = {
        "EDUC": {
            username: "educ@faculty",
            password: "educ123",
            redirect: "/faculty/educ.php"
        },
        "CAS": {
            username: "cas@faculty",
            password: "cas123",
            redirect: "/faculty/cas.php"
        },
        "IT": {
            username: "it@faculty",
            password: "it123",
            redirect: "/faculty/IT.php"
        },
        "ENG": {
            username: "engineering@faculty",
            password: "eng123",
            redirect: "/faculty/eng.php"
        },
        "AGRI": {
            username: "agri@faculty",
            password: "agri123",
            redirect: "/faculty/agri.php"
        }
    };

    if (!dept) {
        errorBox.textContent = "Please select a faculty department.";
        return;
    }

    const account = accounts[dept];

    if (user === account.username && pass === account.password) {

        // Create PHP session
        fetch(`/login/faculty_session.php?email=${encodeURIComponent(account.username)}`)
            .then(res => res.text())
            .then(result => {
                if (result === "ok") {
                    window.location.href = account.redirect;
                } else {
                    errorBox.textContent = "Session error. Try again.";
                }
            });

    } else {
        errorBox.textContent = "Incorrect username or password.";
    }
}
