<?php
// DATABASE CONNECTION
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// FETCH ANNOUNCEMENTS
$sql = "SELECT Title, Content, `Date Posted` 
        FROM admin_announcement 
        ORDER BY `Date Posted` DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>University Dashboard</title>
    <link rel="stylesheet" href="/digitalDesign/studentcss/student_home.css" />

    <style>
        /* CENTER THE NAVIGATION */
        .college-nav {
            display: flex;
            justify-content: center;
            margin-top: -20px;
        }

        .college-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            gap: 20px;
        }

        .college-nav ul li {
            text-align: center;
        }

        .nav-btn {
            padding: 10px 20px;
            background: #004aad;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-size: 17px;
            transition: 0.3s;
        }

        .nav-btn:hover {
            background-color: #003a87;
        }

        /* ANNOUNCEMENTS CARDS FIX */
        .content-cards-container {
            max-width: 950px;
            margin: 30px auto;
        }

        /* Remove profile icon space */
        .user-icon {
            display: none;
        }

        /* Logout Button */
        .logout-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            z-index: 1000;
        }

        .logout-btn:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>

<!-- Header -->
<header class="main-header fade-in">
    <div class="overlay-content">
        <h1>WELCOME, STUDENT!</h1>
    </div>
</header>

<!-- CENTERED Navigation - ONLY INDUSTRIAL TECH -->
<nav class="college-nav slide-down">
    <ul>
        <li><a class="nav-btn" href="it.php">Industrial Technology</a></li>
    </ul>
</nav>

<!-- Announcement Cards -->
<main class="content-cards-container">
<?php if ($result && $result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
        <?php 
            $fullContent = nl2br(htmlspecialchars($row['Content']));
            $shortContent = mb_strimwidth(strip_tags($row['Content']), 0, 120, "...");
        ?>
        <div class="info-card">
            <h3><?= htmlspecialchars($row['Title']) ?></h3>

            <p class="short-text"><?= htmlspecialchars($shortContent) ?></p>

            <p class="full-text" style="display:none;">
                <?= $fullContent ?>
            </p>

            <p class="date"><strong>Date Posted:</strong> <?= htmlspecialchars($row['Date Posted']) ?></p>

            <button class="read-more-btn">READ MORE</button>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p class="empty-msg">No announcements yet.</p>
<?php endif; ?>
</main>

<!-- Modal -->
<div class="modal-overlay">
    <div class="modal-box">
        <h2 id="modal-title"></h2>
        <div id="modal-content"></div>
        <button id="closeModal" class="close-btn">Close</button>
    </div>
</div>

<!-- Logout Button -->
<button class="logout-btn" id="logoutBtn">Log out</button>

<!-- Bottom Navigation -->
<footer class="bottom-nav-bar">
    <a href="student_home.php" class="nav-item active">🏠 HOME</a>
    <a href="setting.php" class="nav-item">⚙️ SETTINGS</a>
</footer>

<script src="/digitaljs/studentjs/student_home.js"></script>
<script>
    document.getElementById('logoutBtn').addEventListener('click', () => {
        if (confirm('Are you sure you want to logout?')) {
            window.location.href = '/login/login.php';
        }
    });
</script>

</body>
</html>

<?php $conn->close(); ?>
