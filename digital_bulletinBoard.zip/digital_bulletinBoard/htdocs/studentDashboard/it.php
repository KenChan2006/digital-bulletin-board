<?php
session_start();

// --- DB CONNECTION
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH ALL APPROVED IT ANNOUNCEMENTS
$sql = "SELECT * FROM it_announcement WHERE status='approved' ORDER BY DatePosted DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Announcements</title>
    <link rel="stylesheet" href="/digitalDesign/studentcss/educ.css">
    <style>
        /* BODY & GENERAL */
        body {
            font-family: Arial, sans-serif;
            background: #f5f0e6; /* light brown background */
            margin: 0;
            padding-bottom: 40px;
        }

        /* TOP NAV */
        nav.top-nav {
            display: flex;
            align-items: center;
            gap: 20px;
            background: #8b5e3c; /* dark brown */
            padding: 15px 20px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            color: #fff;
        }

        nav.top-nav a#backBtn {
            text-decoration: none;
            color: #fff3e0;
            font-weight: bold;
            transition: color 0.3s, transform 0.2s;
        }

        nav.top-nav a#backBtn:hover {
            color: #ffe0b2;
            transform: translateY(-2px);
        }

        /* PAGE HEADER */
        header.edu-header {
            text-align: center;
            padding: 40px 20px;
            background: #d7bfae; /* medium brown */
            border-radius: 0 0 20px 20px;
            margin-bottom: 20px;
        }

        header.edu-header h1 {
            margin: 0;
            font-size: 28px;
            color: #4e342e; /* dark brown text */
        }

        /* ANNOUNCEMENTS */
        .announcement-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            padding: 20px;
        }

        .announcement-card {
            background: #fff3e0; /* light beige for card */
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.2s;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeUp 0.8s ease forwards;
        }

        .announcement-card:hover {
            transform: translateY(-3px);
        }

        .announcement-content {
            margin: 10px 0;
            color: #5d4037;
        }

        .announcement-date {
            font-size: 0.9em;
            color: #6d4c41;
        }

        /* FEEDBACK BUTTON */
        .feedback-btn {
            display: inline-block;
            padding: 8px 15px;
            background: #a0522d; /* brown button */
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
            margin-top: 10px;
            transition: background 0.3s, transform 0.2s;
        }

        .feedback-btn:hover {
            background: #7b3f1f;
            transform: translateY(-2px);
        }

        /* Animations */
        .fade-in {
            animation: fadeIn 1s ease forwards;
        }

        .fade-up {
            animation: fadeUp 0.8s ease forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <!-- TOP NAV BAR -->
    <nav class="top-nav">
        <a href="it_home.php" id="backBtn">⬅ Back</a>
        <h2>College of IT</h2>
    </nav>

    <!-- PAGE HEADER -->
    <header class="edu-header fade-in">
        <h1><br/><br/>College of IT Announcements</h1>
    </header>

    <!-- ANNOUNCEMENT LIST -->
    <main class="announcement-container fade-up">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='announcement-card'>";
                echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
                echo "<p class='announcement-content'>" . nl2br(htmlspecialchars($row['Content'])) . "</p>";
                echo "<p class='announcement-date'>Posted: " . htmlspecialchars($row['DatePosted']) . "</p>";

                // FEEDBACK BUTTON
                echo "<a href='it_feedback.php?announcement_id=" . $row['announcement_id'] . "' class='feedback-btn'>Give Feedback</a>";

                echo "</div>";
            }
        } else {
            echo "<p style='text-align:center; color:#5d4037; font-size:18px;'>No announcements available.</p>";
        }
        ?>
    </main>

</body>
</html>
