<?php
session_start();

// --- CHECK LOGIN ---
if (!isset($_SESSION['user_id'])) {
    header("Location: /login/login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$user_id = $_SESSION['user_id'];

// --- GET USER INFO ---
$stmt = $conn->prepare("SELECT firstname, middlename, lastname, email FROM user WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$fullName = trim(($user['firstname'] ?? '') . " " . ($user['middlename'] ?? '') . " " . ($user['lastname'] ?? ''));
$email = $user['email'] ?? '';

// --- GET ANNOUNCEMENT ---
$announcement_id = intval($_GET['announcement_id'] ?? 0);
$ann = $conn->prepare("SELECT * FROM cas_announcement WHERE announcement_id=? AND status='approved'");
$ann->bind_param("i", $announcement_id);
$ann->execute();
$announcement = $ann->get_result()->fetch_assoc();
$ann->close();

if (!$announcement) {
    echo "<h2>Announcement not found.</h2>";
    exit();
}

// --- SUBMIT FEEDBACK ---
if (isset($_POST['send_feedback'])) {
    $feedback = trim($_POST['feedback_text']);
    $date = date("Y-m-d H:i:s");

    if ($feedback) {
        $stmt = $conn->prepare("INSERT INTO cas_announcement_feedback (announcement_id, user_email, feedback_text, date_sent) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $announcement_id, $email, $feedback, $date);
        $stmt->execute();
        $stmt->close();
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    }
}

// --- DELETE FEEDBACK ---
if (isset($_POST['delete_feedback'])) {
    $feedback_id = intval($_POST['feedback_id']);
    // ensure only the owner can delete
    $check = $conn->prepare("SELECT * FROM cas_announcement_feedback WHERE feedback_id=? AND user_email=?");
    $check->bind_param("is", $feedback_id, $email);
    $check->execute();
    $res = $check->get_result();
    if ($res->num_rows > 0) {
        $del = $conn->prepare("DELETE FROM cas_announcement_feedback WHERE feedback_id=?");
        $del->bind_param("i", $feedback_id);
        $del->execute();
        $del->close();
    }
    $check->close();
}

// --- FETCH ALL FEEDBACK ---
$stmt = $conn->prepare("
SELECT f.feedback_id, f.feedback_text, f.date_sent, f.user_email,
       u.firstname, u.middlename, u.lastname
FROM cas_announcement_feedback f
LEFT JOIN user u ON f.user_email = u.email
WHERE f.announcement_id=?
ORDER BY f.feedback_id DESC
");
$stmt->bind_param("i", $announcement_id);
$stmt->execute();
$feedbackResult = $stmt->get_result();
$feedbackRows = [];
$feedbackIds = [];
while ($row = $feedbackResult->fetch_assoc()) {
    $feedbackRows[$row['feedback_id']] = $row;
    $feedbackIds[] = $row['feedback_id'];
}
$stmt->close();

// --- FETCH ALL REPLIES ---
$repliesByFeedback = [];
if (!empty($feedbackIds)) {
    $ids = implode(',', $feedbackIds);
    $query = "
    SELECT r.feedback_id, r.reply_id, r.reply_text, r.date_sent
    FROM cas_feedback_replies r
    WHERE r.feedback_id IN ($ids)
    ORDER BY r.date_sent ASC
    ";
    $result = $conn->query($query);
    while ($r = $result->fetch_assoc()) {
        $repliesByFeedback[$r['feedback_id']][] = $r;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Announcement Feedback</title>
<style>
body { 
    font-family: Arial, sans-serif; 
    background: #fffbe6; 
    margin:0; 
    padding-bottom:40px; 
    transition: background 0.3s ease;
}

.back-btn { 
    margin:20px; 
    background:#f7c948; 
    color:#333; 
    padding:10px 20px; 
    border-radius:8px; 
    text-decoration:none; 
    display:inline-block; 
    transition: transform 0.2s, box-shadow 0.2s;
}
.back-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.announcement-box, .feedback-form, .feedback-box {
    width:90%; 
    max-width:900px; 
    background:white; 
    margin:20px auto;
    padding:20px; 
    border-radius:12px; 
    box-shadow:0 4px 20px rgba(0,0,0,0.1);
    transition: transform 0.2s, box-shadow 0.2s;
}
.announcement-box:hover, .feedback-box:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.reply-box {
    background:#fff4b3; 
    padding:12px; 
    border-left:4px solid #f7c948; 
    margin-top:10px; 
    border-radius:8px; 
    transition: background 0.3s;
}
.reply-box:hover {
    background:#ffe066;
}

.delete-btn {
    background:#ff6b6b; 
    color:white; 
    padding:6px 12px; 
    border-radius:5px; 
    border:none; 
    cursor:pointer; 
    transition: background 0.3s, transform 0.2s;
}
.delete-btn:hover {
    background:#ff4c4c;
    transform: translateY(-2px);
}

textarea { 
    width:100%; 
    padding:10px; 
    border-radius:5px; 
    border:1px solid #f7c948; 
    background:#fffbea; 
    transition: border-color 0.3s, background 0.3s;
}
textarea:focus {
    border-color:#f4b400;
    background:#fff7cc;
    outline:none;
}

button { 
    padding:10px 16px; 
    border-radius:5px; 
    border:none; 
    background:#f7c948; 
    color:white; 
    cursor:pointer; 
    font-weight:bold;
    transition: background 0.3s, transform 0.2s;
}
button:hover {
    background:#f4b400;
    transform: translateY(-2px);
}

h3 { 
    text-align:center; 
    color:#b58300;
}

h2 { 
    color:#ad7c00;
    margin-bottom:10px;
}

p, small, i { 
    color:#333;
}

.feedback-form {
    animation: fadeIn 0.8s ease-out;
}

.feedback-box {
    animation: fadeInUp 0.8s ease-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>

<a href="cas.php" class="back-btn">⬅ BACK</a>

<!-- ANNOUNCEMENT -->
<div class="announcement-box">
    <h2><?php echo htmlspecialchars($announcement['Title']); ?></h2>
    <p><?php echo nl2br(htmlspecialchars($announcement['Content'])); ?></p>
    <small><i>Posted: <?php echo $announcement['Date_posted']; ?></i></small>
</div>

<!-- FEEDBACK FORM -->
<div class="feedback-form">
    <h3>Send your feedback</h3>
    <form method="POST">
        <textarea name="feedback_text" required style="height:100px;"></textarea>
        <br><br>
        <button type="submit" name="send_feedback">Submit</button>
    </form>
</div>

<h3 style="text-align:center;">Feedback</h3>

<?php foreach ($feedbackRows as $row): ?>
<div class="feedback-box">

    <!-- STUDENT NAME -->
    <p><b>
        <?php 
            $name = trim(($row['firstname'] ?? '') . " " . ($row['middlename'] ?? '') . " " . ($row['lastname'] ?? ''));
            echo !empty($name) ? htmlspecialchars($name) : htmlspecialchars($row['user_email']);
        ?>
    </b></p>

    <!-- FEEDBACK TEXT -->
    <p><?php echo nl2br(htmlspecialchars($row['feedback_text'])); ?></p>
    <p><i>Sent: <?php echo $row['date_sent']; ?></i></p>

    <!-- DELETE BUTTON -->
    <?php if (strtolower(trim($row['user_email'])) === strtolower(trim($email))): ?>
    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this feedback?');">
        <input type="hidden" name="feedback_id" value="<?php echo $row['feedback_id']; ?>">
        <button type="submit" name="delete_feedback" class="delete-btn">Delete</button>
    </form>
    <?php endif; ?>

    <!-- FACULTY REPLIES -->
    <?php if (!empty($repliesByFeedback[$row['feedback_id']])): ?>
        <?php foreach ($repliesByFeedback[$row['feedback_id']] as $rep): ?>
        <div class="reply-box">
            <b>Faculty Reply:</b><br>
            <?php echo nl2br(htmlspecialchars($rep['reply_text'])); ?><br>
            <small><i>Replied: <?php echo $rep['date_sent']; ?></i></small>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>

</div>
<?php endforeach; ?>

</body>
</html>
