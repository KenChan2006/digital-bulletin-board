<?php
session_start();

// --- DB CONNECTION ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH ALL APPROVED EDUC ANNOUNCEMENTS ---
$sql = "SELECT * FROM educ_announcement WHERE status='approved' ORDER BY DatePosted DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Education Announcements</title>
    <style>
        /* GENERAL STYLING */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #00008B; /* Blue text */
        }

        /* TOP NAV BAR */
        .top-nav {
            display: flex;
            align-items: center;
            background-color: #1E90FF; /* Blue background */
            color: white;
            padding: 10px 20px;
        }

        .top-nav a {
            text-decoration: none;
            color: white;
            margin-right: 20px;
            font-weight: bold;
        }

        /* PAGE HEADER */
        .edu-header {
            text-align: center;
            padding: 40px 20px;
            background-color: #87CEFA; /* Lighter blue */
            color: #00008B;
            animation: fadeInAnimation 3s infinite alternate;
        }

        /* ANNOUNCEMENT CONTAINER */
        .announcement-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        /* ANNOUNCEMENT CARD */
        .announcement-card {
            background-color: #E6F0FA; /* Light blue */
            border-left: 5px solid #00008B;
            padding: 20px;
            margin: 10px 0;
            width: 80%;
            box-shadow: 0 2px 5px rgba(0,0,139,0.2);
            animation: fadeUpAnimation 2s infinite alternate;
        }

        .announcement-card h3 {
            color: #00008B;
        }

        .announcement-card p {
            color: #00008B;
        }

        /* FEEDBACK BUTTON */
        .feedback-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #00008B; /* Blue button */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .feedback-btn:hover {
            background-color: #1E90FF; /* Lighter blue on hover */
        }

        /* ANIMATIONS */
        @keyframes fadeInAnimation {
            0% {opacity: 0;}
            50% {opacity: 0.7;}
            100% {opacity: 1;}
        }

        @keyframes fadeUpAnimation {
            0% {transform: translateY(0px);}
            50% {transform: translateY(-10px);}
            100% {transform: translateY(0px);}
        }

        .fade-in {
            animation: fadeInAnimation 3s infinite alternate;
        }

        .fade-up {
            animation: fadeUpAnimation 2s infinite alternate;
        }
    </style>
</head>
<body>

    <!-- TOP NAV BAR -->
    <nav class="top-nav">
        <a href="educ_home.php" id="backBtn">⬅ Back</a>
        <h2>College of Education</h2>
    </nav>

    <!-- PAGE HEADER -->
    <header class="edu-header fade-in">
        <h1>College of Education<br/>Announcements</h1>
    </header>

    <!-- ANNOUNCEMENT LIST -->
    <main class="announcement-container fade-up">

        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                echo "<div class='announcement-card'>";
                echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
                echo "<p class='announcement-content'>" . nl2br(htmlspecialchars($row['Content'])) . "</p>";
                echo "<p class='announcement-date'>Posted: " . htmlspecialchars($row['DatePosted']) . "</p>";

                // FEEDBACK BUTTON
                echo "<a href='educ_feedback.php?announcement_id=" . $row['announcement_id'] . "' class='feedback-btn'>";
                echo "Give Feedback</a>";

                echo "</div>";
            }
        } else {
            echo "<p style='text-align:center; color:#555; font-size:18px;'>No announcements available.</p>";
        }
        ?>

    </main>

</body>
</html>
