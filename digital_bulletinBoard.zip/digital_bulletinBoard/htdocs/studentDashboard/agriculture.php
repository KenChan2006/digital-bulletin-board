<?php
session_start();

// --- DB CONNECTION
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH ALL APPROVED AGRICULTURE ANNOUNCEMENTS
$sql = "SELECT * FROM agriculture_announcement WHERE status='approved' ORDER BY DatePosted DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agriculture Announcements</title>
<link rel="stylesheet" href="/digitalDesign/studentcss/educ.css">
<style>
/* GENERAL BODY */
body {
    font-family: Arial, sans-serif;
    background: #e6f2e6; /* light green background */
    margin: 0;
    padding-bottom: 40px;
}

/* TOP NAV */
nav.top-nav {
    display: flex;
    align-items: center;
    gap: 20px;
    background: #d9f0d9; /* light green */
    padding: 15px 20px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
nav.top-nav a#backBtn {
    text-decoration: none;
    color: #2e7d32; /* dark green */
    font-weight: bold;
    transition: color 0.3s;
}
nav.top-nav a#backBtn:hover {
    color: #1b5e20;
}

/* PAGE HEADER */
header.edu-header {
    text-align: center;
    padding: 40px 20px;
    background: #c8e6c9; /* medium green */
    border-radius: 0 0 20px 20px;
    margin-bottom: 20px;
}
header.edu-header h1 {
    margin: 0;
    font-size: 28px;
    color: #1b5e20; /* dark green */
}

/* ANNOUNCEMENT CONTAINER */
.announcement-container {
    display: flex;
    flex-direction: column;
    gap: 20px;
    padding: 20px;
    opacity: 0;
    transform: translateY(20px);
    animation: fadeUp 0.8s ease forwards;
}

/* ANNOUNCEMENT CARD */
.announcement-card {
    background: #a5d6a7; /* green card */
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    transition: transform 0.2s, background 0.3s;
}
.announcement-card:hover {
    transform: translateY(-3px);
    background: #81c784; /* darker green on hover */
}

.announcement-content {
    margin: 10px 0;
}

.announcement-date {
    font-size: 0.9em;
    color: #2e7d32; /* dark green */
}

/* FEEDBACK BUTTON */
.feedback-btn {
    display: inline-block;
    padding: 8px 15px;
    background: #388e3c; /* green */
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    margin-top: 10px;
    transition: background 0.3s, transform 0.2s;
}
.feedback-btn:hover {
    background: #1b5e20;
    transform: translateY(-2px);
}

/* ANIMATION */
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>

<!-- TOP NAV BAR -->
<nav class="top-nav">
    <a href="agriculture_home.php" id="backBtn">⬅ Back</a>
    <h2>College of Agriculture</h2>
</nav>

<!-- PAGE HEADER -->
<header class="edu-header fade-in">
    <h1><br/><br/>College of Agriculture Announcements</h1>
</header>

<!-- ANNOUNCEMENT LIST -->
<main class="announcement-container fade-up">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='announcement-card'>";
            echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
            echo "<p class='announcement-content'>" . nl2br(htmlspecialchars($row['Content'])) . "</p>";
            echo "<p class='announcement-date'>Posted: " . htmlspecialchars($row['DatePosted']) . "</p>";

            // FEEDBACK BUTTON
            echo "<a href='agriculture_feedback.php?announcement_id=" . $row['announcement_id'] . "' class='feedback-btn'>Give Feedback</a>";

            echo "</div>";
        }
    } else {
        echo "<p style='text-align:center; color:#2e7d32; font-size:18px;'>No announcements available.</p>";
    }
    ?>
</main>

</body>
</html>
