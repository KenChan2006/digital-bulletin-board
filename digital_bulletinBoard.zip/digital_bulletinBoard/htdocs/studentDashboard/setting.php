<?php
session_start();

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /login/login.php");
    exit();
}

// DB Connection
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$error = $success = "";

// --- Handle Profile Update ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Update Profile Info
    if (isset($_POST['update_profile'])) {
        $fname = trim($_POST['fname']);
        $mname = trim($_POST['mname']);
        $lname = trim($_POST['lname']);
        $email_new = trim($_POST['email']);

        if ($fname && $mname && $lname && $email_new) {
            $stmt = $conn->prepare("UPDATE user SET firstname=?, middlename=?, lastname=?, email=? WHERE id=?");
            $stmt->bind_param("ssssi", $fname, $mname, $lname, $email_new, $user_id);
            if ($stmt->execute()) {
                $success = "Profile updated successfully!";
            } else {
                $error = "Error updating profile: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "Please fill all profile fields.";
        }
    }

    // Change Password
    if (isset($_POST['change_password'])) {
        $old_pass = $_POST['old_pass'] ?? '';
        $new_pass = $_POST['new_pass'] ?? '';

        if ($old_pass && $new_pass) {
            $stmt = $conn->prepare("SELECT password FROM user WHERE id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->bind_result($current_hash);
            $stmt->fetch();
            $stmt->close();

            if (password_verify($old_pass, $current_hash)) {
                $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE user SET password=? WHERE id=?");
                $stmt->bind_param("si", $new_hash, $user_id);
                if ($stmt->execute()) {
                    $success = "Password changed successfully!";
                } else {
                    $error = "Error changing password: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = "Old password is incorrect.";
            }
        } else {
            $error = "Please provide old and new passwords.";
        }
    }
}

// --- Load user info from user table ---
$stmt = $conn->prepare("SELECT firstname, middlename, lastname, email FROM user WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($fname, $mname, $lname, $email);
$stmt->fetch();
$stmt->close();

// --- Load student info (school_id, college) from studentuser table ---
$stmt = $conn->prepare("SELECT school_id, college FROM studentuser WHERE email=? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($school_id, $college);
$stmt->fetch();
$stmt->close();

// Normalize college for display & back button
$college = strtoupper(trim($college));

// College pages mapping
$college_pages = [
    'CAS' => '/studentDashboard/cas_home.php',
    'AGRICULTURE' => '/studentDashboard/agriculture_home.php',
    'ENGINEERING' => '/studentDashboard/eng_home.php',
    'EDUC' => '/studentDashboard/educ_home.php',
    'IT' =>  '/studentDashboard/it_home.php'
];

// Determine back button URL
$back_url = $college_pages[$college] ?? '/studentDashboard/educ_home.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Settings</title>
<style>
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #1f1c2c, #928dab); color: #fff; margin:0; padding:0; min-height:100vh; }
.back-btn { position: fixed; top:20px; left:20px; padding:10px 16px; background-color: rgba(255,255,255,0.1); color:#fff; font-weight:600; border-radius:8px; border:1px solid rgba(255,255,255,0.2); text-decoration:none; }
.back-btn:hover { background-color: rgba(0,123,255,0.8); }
.settings-header { text-align:center; padding:50px 20px 30px; }
.settings-header h1 { font-size:32px; margin:0; color:#fff; }
.settings-header p { color:#ddd; font-size:17px; }
.settings-section { max-width:520px; margin:25px auto; padding:25px 30px; background: rgba(0,0,0,0.4); border-radius:15px; border:1px solid rgba(255,255,255,0.2); backdrop-filter: blur(10px); }
.settings-section h2 { margin-bottom:20px; color:#0abde3; }
.settings-section form { display:flex; flex-direction:column; gap:12px; }
.settings-section form input { padding:12px 14px; border-radius:8px; border:1px solid rgba(255,255,255,0.3); font-size:15px; background-color: rgba(255,255,255,0.05); color:#fff; }
.settings-section form input[readonly] { background-color: rgba(255,255,255,0.1); cursor:not-allowed; }
.settings-section form button { margin-top:15px; padding:12px; border-radius:10px; border:none; background:linear-gradient(90deg, #0abde3, #10ac84); color:#fff; font-size:16px; font-weight:600; cursor:pointer; }
.success-msg, .error-msg { text-align:center; font-size:17px; padding:12px 20px; margin:20px auto; width:fit-content; border-radius:8px; }
.success-msg { background-color: rgba(72, 187, 120, 0.8); color:#fff; border:1px solid rgba(72,187,120,0.9); }
.error-msg { background-color: rgba(220, 53, 69, 0.8); color:#fff; border:1px solid rgba(220,53,69,0.9); }
</style>
</head>
<body>

<a href="<?php echo htmlspecialchars($back_url); ?>" class="back-btn">⬅ Back</a>

<header class="settings-header">
    <h1>Settings</h1>
    <p>Manage your account preferences and security below.</p>
</header>

<?php if ($error) echo '<p class="error-msg">'.$error.'</p>'; ?>
<?php if ($success) echo '<p class="success-msg">'.$success.'</p>'; ?>

<section class="settings-section">
    <h2>Profile Settings</h2>
    <form method="POST">
        <input type="hidden" name="update_profile" value="1">

        <label>School ID:</label>
        <input type="text" value="<?php echo htmlspecialchars($school_id); ?>" readonly>

        <label>College:</label>
        <input type="text" value="<?php echo htmlspecialchars($college); ?>" readonly>

        <label>First Name:</label>
        <input type="text" name="fname" value="<?php echo htmlspecialchars($fname); ?>" required>

        <label>Middle Name:</label>
        <input type="text" name="mname" value="<?php echo htmlspecialchars($mname); ?>" required>

        <label>Last Name:</label>
        <input type="text" name="lname" value="<?php echo htmlspecialchars($lname); ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>

        <button type="submit">Update Profile</button>
    </form>
</section>

<section class="settings-section">
    <h2>Account Security</h2>
    <form method="POST">
        <input type="hidden" name="change_password" value="1">

        <label>Old Password:</label>
        <input type="password" name="old_pass" required>

        <label>New Password:</label>
        <input type="password" name="new_pass" required>

        <button type="submit">Change Password</button>
    </form>
</section>

<script>
// Auto fade-out messages
setTimeout(() => {
    const successMsg = document.querySelector('.success-msg');
    const errorMsg = document.querySelector('.error-msg');
    if(successMsg) successMsg.style.opacity = '0';
    if(errorMsg) errorMsg.style.opacity = '0';
}, 4000);
</script>

</body>
</html>
