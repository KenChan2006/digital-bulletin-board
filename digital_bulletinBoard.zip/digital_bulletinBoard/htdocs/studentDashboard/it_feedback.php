<?php
session_start();

// --- CHECK LOGIN ---
if (!isset($_SESSION['user_id'])) {
    header("Location: /login/login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$user_id = $_SESSION['user_id'];

// --- GET USER INFO ---
$stmt = $conn->prepare("SELECT firstname, middlename, lastname, email FROM user WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$fullName = trim(($user['firstname'] ?? '') . " " . ($user['middlename'] ?? '') . " " . ($user['lastname'] ?? ''));
$email = $user['email'] ?? '';

// --- GET ANNOUNCEMENT ---
$announcement_id = intval($_GET['announcement_id'] ?? 0);
$ann = $conn->prepare("SELECT * FROM it_announcement WHERE announcement_id=? AND status='approved'");
$ann->bind_param("i", $announcement_id);
$ann->execute();
$announcement = $ann->get_result()->fetch_assoc();
$ann->close();

if (!$announcement) {
    echo "<h2>Announcement not found.</h2>";
    exit();
}

// --- SUBMIT FEEDBACK ---
if (isset($_POST['send_feedback'])) {
    $feedback = trim($_POST['feedback_text']);
    $date = date("Y-m-d H:i:s");

    if ($feedback) {
        $stmt = $conn->prepare("INSERT INTO it_announcement_feedback (announcement_id, user_email, feedback_text, date_sent) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $announcement_id, $email, $feedback, $date);
        $stmt->execute();
        $stmt->close();
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    }
}

// --- DELETE FEEDBACK ---
if (isset($_POST['delete_feedback'])) {
    $feedback_id = intval($_POST['feedback_id']);
    $check = $conn->prepare("SELECT * FROM it_announcement_feedback WHERE feedback_id=? AND user_email=?");
    $check->bind_param("is", $feedback_id, $email);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {

        $delReplies = $conn->prepare("DELETE FROM it_feedback_replies WHERE feedback_id=?");
        $delReplies->bind_param("i", $feedback_id);
        $delReplies->execute();
        $delReplies->close();

        $del = $conn->prepare("DELETE FROM it_announcement_feedback WHERE feedback_id=?");
        $del->bind_param("i", $feedback_id);
        $del->execute();
        $del->close();
    }
    $check->close();
}

// --- FETCH ALL FEEDBACK + STUDENT NAMES + FACULTY REPLIES ---
$query = "
SELECT 
    f.feedback_id,
    f.feedback_text,
    f.date_sent,
    f.user_email,

    -- STUDENT NAME
    su.firstname AS s_firstname,
    su.middlename AS s_middlename,
    su.lastname AS s_lastname,

    -- FACULTY REPLY
    r.reply_id,
    r.reply_text,
    r.date_sent AS reply_date,
    r.faculty_id,
    fu.firstname AS f_firstname,
    fu.middlename AS f_middlename,
    fu.lastname AS f_lastname

FROM it_announcement_feedback f
LEFT JOIN user su ON su.email = f.user_email       -- student name
LEFT JOIN it_feedback_replies r ON r.feedback_id = f.feedback_id
LEFT JOIN user fu ON fu.id = r.faculty_id          -- faculty name
WHERE f.announcement_id=?
ORDER BY f.feedback_id DESC, r.date_sent ASC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $announcement_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

// GROUP FEEDBACK + REPLIES
$feedbacks = [];
while ($row = $result->fetch_assoc()) {

    $fb_id = $row['feedback_id'];

    // BUILD STUDENT FULL NAME
    $student_fullname = trim(
        ($row['s_firstname'] ?? '') . " " .
        ($row['s_middlename'] ?? '') . " " .
        ($row['s_lastname'] ?? '')
    );

    if (!isset($feedbacks[$fb_id])) {
        $feedbacks[$fb_id] = [
            'feedback_text' => $row['feedback_text'],
            'date_sent' => $row['date_sent'],

            // DISPLAY NAME INSTEAD OF EMAIL
            'student_name' => $student_fullname ?: $row['user_email'],

            'replies' => []
        ];
    }

    // FACULTY REPLY NAME
    if (!empty($row['reply_text'])) {

        $faculty_fullname = trim(
            ($row['f_firstname'] ?? '') . " " .
            ($row['f_middlename'] ?? '') . " " .
            ($row['f_lastname'] ?? '')
        );

        $feedbacks[$fb_id]['replies'][] = [
            'reply_text' => $row['reply_text'],
            'reply_date' => $row['reply_date'],
            'faculty_name' => $faculty_fullname ?: 'Faculty'
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>IT Announcement Feedback</title>

<style>
/* BODY & GENERAL */
body { 
    font-family: Arial, sans-serif; 
    background: #f5f0e6;
    margin: 0; 
    padding-bottom: 40px; 
}

/* BACK BUTTON */
.back-btn { 
    margin: 20px; 
    background:#8b5e3c; 
    color:#fff; 
    padding:10px 20px; 
    border-radius:8px; 
    text-decoration:none; 
    display:inline-block; 
    transition: background 0.3s, transform 0.2s; 
}
.back-btn:hover { 
    background: #5d3a1a; 
    transform: translateY(-2px); 
}

/* BOXES */
.announcement-box, .feedback-form, .feedback-box {
    width:90%; max-width:900px; 
    background:#d7bfae; 
    margin:20px auto; 
    padding:20px; 
    border-radius:12px; 
    box-shadow:0 4px 15px rgba(0,0,0,0.1);
    opacity: 0;
    transform: translateY(20px);
    animation: fadeUp 0.8s ease forwards;
}

.announcement-box { animation-delay: 0.1s; }
.feedback-form { animation-delay: 0.3s; }
.feedback-box { animation-delay: 0.5s; }

/* REPLY BOX */
.reply-box {
    background:#e0c6a6;
    padding:10px; 
    border-left:4px solid #8b5e3c; 
    margin-top:10px; 
    border-radius:8px;
    animation: fadeUp 0.8s ease forwards;
}

/* DELETE BUTTON */
.delete-btn {
    background:#8b5e3c; 
    color:white; 
    padding:6px 12px; 
    border-radius:5px; 
    border:none; 
    cursor:pointer;
    transition: background 0.3s, transform 0.2s;
}
.delete-btn:hover {
    background:#5d3a1a;
    transform: translateY(-1px);
}

/* TEXTAREA & BUTTON */
textarea { 
    width:100%; 
    padding:8px; 
    border-radius:6px; 
    border:1px solid #8b5e3c; 
}
button { 
    padding:8px 12px; 
    border:none; 
    border-radius:6px; 
    background:#8b5e3c; 
    color:white; 
    cursor:pointer; 
    margin-top:5px;
    transition: background 0.3s, transform 0.2s;
}
button:hover {
    background:#5d3a1a;
    transform: translateY(-1px);
}

h2, h3 { color:#5d3a1a; }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>

<a href="it.php" class="back-btn">⬅ BACK</a>

<!-- MAIN ANNOUNCEMENT -->
<div class="announcement-box">
    <h2><?php echo htmlspecialchars($announcement['Title']); ?></h2>
    <p><?php echo nl2br(htmlspecialchars($announcement['Content'])); ?></p>
    <small><i>Posted on: <?php echo $announcement['DatePosted']; ?></i></small>
</div>

<!-- FEEDBACK FORM -->
<div class="feedback-form">
    <h3>Send your feedback</h3>
    <form method="POST">
        <textarea name="feedback_text" required style="height:100px;"></textarea>
        <button type="submit" name="send_feedback">Submit</button>
    </form>
</div>

<h3 style="text-align:center; color:#5d3a1a;">Feedback</h3>

<?php foreach ($feedbacks as $fb_id => $fb): ?>
<div class="feedback-box">

    <!-- STUDENT NAME INSTEAD OF EMAIL -->
    <p><b><?php echo htmlspecialchars($fb['student_name']); ?></b></p>

    <p><?php echo nl2br(htmlspecialchars($fb['feedback_text'])); ?></p>
    <p><i>Sent: <?php echo $fb['date_sent']; ?></i></p>

    <!-- DELETE BUTTON -->
    <?php if ($fb['student_name'] === $fullName || $fb['student_name'] === $email): ?>
    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this feedback?');">
        <input type="hidden" name="feedback_id" value="<?php echo $fb_id; ?>">
        <button type="submit" name="delete_feedback" class="delete-btn">Delete</button>
    </form>
    <?php endif; ?>

    <!-- FACULTY REPLIES -->
    <?php foreach ($fb['replies'] as $rep): ?>
        <div class="reply-box">
            <b><?php echo htmlspecialchars($rep['faculty_name']); ?>:</b><br>
            <?php echo nl2br(htmlspecialchars($rep['reply_text'])); ?><br>
            <small><i>Replied: <?php echo $rep['reply_date']; ?></i></small>
        </div>
    <?php endforeach; ?>

</div>
<?php endforeach; ?>

</body>
</html>
