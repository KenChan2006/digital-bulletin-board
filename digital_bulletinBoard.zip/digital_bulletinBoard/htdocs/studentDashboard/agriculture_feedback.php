<?php
session_start();

// --- CHECK LOGIN ---
if (!isset($_SESSION['user_id'])) {
    header("Location: /login/login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$user_id = $_SESSION['user_id'];

// --- GET USER INFO ---
$stmt = $conn->prepare("SELECT firstname, middlename, lastname, email FROM user WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$fullName = trim(($user['firstname'] ?? '') . " " . ($user['middlename'] ?? '') . " " . ($user['lastname'] ?? ''));
$email = $user['email'] ?? '';

// --- GET ANNOUNCEMENT ---
$announcement_id = intval($_GET['announcement_id'] ?? 0);
$ann = $conn->prepare("SELECT * FROM agriculture_announcement WHERE announcement_id=? AND status='approved'");
$ann->bind_param("i", $announcement_id);
$ann->execute();
$announcement = $ann->get_result()->fetch_assoc();
$ann->close();

if (!$announcement) {
    echo "<h2>Announcement not found.</h2>";
    exit();
}

// --- SUBMIT FEEDBACK ---
if (isset($_POST['send_feedback'])) {
    $feedback = trim($_POST['feedback_text']);
    $date = date("Y-m-d H:i:s");

    if ($feedback) {
        $stmt = $conn->prepare("
            INSERT INTO agriculture_announcement_feedback 
            (announcement_id, user_email, feedback_text, date_sent)
            VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $announcement_id, $email, $feedback, $date);
        $stmt->execute();
        $stmt->close();

        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    }
}

// --- DELETE FEEDBACK ---
if (isset($_POST['delete_feedback'])) {
    $feedback_id = intval($_POST['feedback_id']);

    $check = $conn->prepare("SELECT * FROM agriculture_announcement_feedback WHERE feedback_id=? AND user_email=?");
    $check->bind_param("is", $feedback_id, $email);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {
        $del = $conn->prepare("DELETE FROM agriculture_announcement_feedback WHERE feedback_id=?");
        $del->bind_param("i", $feedback_id);
        $del->execute();
        $del->close();
    }
    $check->close();
}

// --- FETCH FEEDBACK + FACULTY REPLIES ---
$query = "
SELECT f.feedback_id, f.feedback_text, f.date_sent, f.user_email,
       u.firstname, u.middlename, u.lastname,
       r.reply_text, r.date_sent AS reply_date
FROM agriculture_announcement_feedback f
LEFT JOIN user u ON f.user_email = u.email
LEFT JOIN agriculture_feedback_replies r ON f.feedback_id = r.feedback_id
WHERE f.announcement_id=?
ORDER BY f.feedback_id DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $announcement_id);
$stmt->execute();
$feedbackList = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Announcement Feedback</title>

<style>
/* PAGE FADE IN */
body { 
    font-family: Arial; 
    background: #e9f7ec; 
    margin:0; 
    padding-bottom:40px; 
    animation: fadeIn 0.7s ease-in-out;
}
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* BACK BUTTON */
.back-btn { 
    margin:20px; 
    background:#2e8b57; 
    color:#fff; 
    padding:10px 20px; 
    border-radius:8px; 
    text-decoration:none; 
    display:inline-block;
    transition:0.3s;
}
.back-btn:hover {
    background:#267648;
    transform: scale(1.05);
}

/* ANNOUNCEMENT + FEEDBACK CARD */
.announcement-box, .feedback-form, .feedback-box {
    width:90%; 
    max-width:900px; 
    background:white; 
    margin:20px auto; 
    padding:20px; 
    border-radius:12px; 
    border-left:5px solid #2e8b57;
    box-shadow:0 4px 15px rgba(0,0,0,0.1);
    
    animation: slideUp 0.5s ease, fadeInCard 0.7s ease;
}

@keyframes slideUp {
    from { transform: translateY(20px); }
    to { transform: translateY(0); }
}
@keyframes fadeInCard {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* FACULTY REPLY BOX */
.reply-box {
    background:#dff5e9; 
    padding:10px; 
    border-left:4px solid #2e8b57; 
    margin-top:10px; 
    border-radius:8px;

    animation: replyFade 0.6s ease;
}
@keyframes replyFade {
    from { opacity:0; transform:translateX(10px); }
    to { opacity:1; transform:translateX(0); }
}

/* BUTTONS */
button {
    background:#2e8b57; 
    color:white; 
    padding:10px 15px; 
    border:none; 
    border-radius:6px; 
    cursor:pointer; 
    margin-top:10px;
    transition:0.25s;
}
button:hover {
    background:#267648;
    transform:scale(1.05);
}

/* DELETE BUTTON */
.delete-btn {
    background:#c0392b; 
    color:white; 
    padding:6px 12px; 
    border-radius:5px; 
    border:none; 
    cursor:pointer;
    transition:0.25s;
}
.delete-btn:hover {
    background:#a52820;
    transform:scale(1.05);
}
</style>

</head>
<body>

<a href="agriculture.php" class="back-btn">⬅ BACK</a>

<!-- MAIN ANNOUNCEMENT -->
<div class="announcement-box">
    <h2><?php echo htmlspecialchars($announcement['Title']); ?></h2>
    <p><?php echo nl2br(htmlspecialchars($announcement['Content'])); ?></p>
</div>

<!-- FEEDBACK FORM -->
<div class="feedback-form">
    <h3>Send your feedback</h3>
    <form method="POST">
        <textarea name="feedback_text" required style="width:100%; height:100px;"></textarea>
        <button type="submit" name="send_feedback">Submit</button>
    </form>
</div>

<h3 style="text-align:center;">Feedback</h3>

<?php while ($row = $feedbackList->fetch_assoc()): ?>
<div class="feedback-box">

    <!-- STUDENT NAME -->
    <p><b>
        <?php 
            $name = trim(($row['firstname'] ?? '') . " " . ($row['middlename'] ?? '') . " " . ($row['lastname'] ?? ''));
            echo !empty($name) ? htmlspecialchars($name) : htmlspecialchars($row['user_email']);
        ?>
    </b></p>

    <!-- FEEDBACK TEXT -->
    <p><?php echo nl2br(htmlspecialchars($row['feedback_text'])); ?></p>
    <p><i>Sent: <?php echo $row['date_sent']; ?></i></p>

    <!-- DELETE BUTTON -->
    <?php if ($row['user_email'] === $email): ?>
    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this feedback?');">
        <input type="hidden" name="feedback_id" value="<?php echo $row['feedback_id']; ?>">
        <button type="submit" name="delete_feedback" class="delete-btn">Delete</button>
    </form>
    <?php endif; ?>

    <!-- FACULTY REPLY -->
    <?php if (!empty($row['reply_text'])): ?>
        <div class="reply-box">
            <b>Faculty Reply:</b><br>
            <?php echo nl2br(htmlspecialchars($row['reply_text'])); ?><br>
            <small><i>Replied: <?php echo $row['reply_date']; ?></i></small>
        </div>
    <?php endif; ?>

</div>
<?php endwhile; ?>

</body>
</html>
