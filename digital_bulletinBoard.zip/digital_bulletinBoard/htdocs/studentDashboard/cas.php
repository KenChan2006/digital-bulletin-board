<?php
session_start();

// ============================
// DATABASE CONNECTION
// ============================
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ============================
// FETCH ALL APPROVED CAS ANNOUNCEMENTS
// ============================
// Wala tayong expiration filter; lahat ng approved announcements ay makikita
$sql = "SELECT * FROM cas_announcement WHERE status='approved' ORDER BY Date_posted DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CAS Announcements</title>
<style>
    body { 
        font-family: Arial, sans-serif; 
        background: #fff9e6; /* light yellow background */
        margin: 0; 
        padding: 0; 
    }
    
    /* Top Navigation */
    nav.top-nav {
        display: flex;
        align-items: center;
        gap: 20px;
        background: #fff3b0; /* yellow nav */
        padding: 15px 20px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    nav.top-nav a#backBtn {
        text-decoration: none;
        color: #b37f00; /* dark yellow text */
        font-weight: bold;
    }

    /* Page Header */
    header.edu-header {
        text-align: center;
        padding: 40px 20px;
        background: #fff1a8; /* yellow header */
        border-radius: 0 0 20px 20px;
        margin-bottom: 20px;
        position: relative;
        overflow: hidden;
    }
    header.edu-header h1 {
        margin: 0;
        font-size: 28px;
        color: #b37f00; /* dark yellow text */
        animation: headerGlow 2s ease-in-out infinite alternate;
    }

    /* Announcement Container */
    .announcement-container {
        display: flex;
        flex-direction: column;
        gap: 20px;
        padding: 20px;
        max-width: 900px;
        margin: auto;
    }

    /* Announcement Card */
    .announcement-card {
        background: #fff8cc; /* light yellow card */
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    .announcement-card:hover {
        transform: translateY(-5px) scale(1.02);
        box-shadow: 0 8px 25px rgba(0,0,0,0.2);
    }
    .announcement-content {
        margin: 10px 0;
    }
    .announcement-date {
        font-size: 0.9em;
        color: #7a5e00; /* darker yellow/brown */
    }

    /* Feedback Button */
    .feedback-btn {
        display: inline-block;
        padding: 8px 15px;
        background: #ffdd57; /* yellow button */
        color: #7a5e00; /* dark text */
        border-radius: 8px;
        text-decoration: none;
        margin-top: 10px;
        transition: background 0.3s ease, transform 0.3s ease;
    }
    .feedback-btn:hover {
        background: #ffca00;
        transform: scale(1.05);
    }

    /* Animations */
    .fade-in {
        animation: fadeIn 1s ease forwards;
    }
    .fade-up {
        animation: fadeUp 0.8s ease forwards;
    }
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    @keyframes fadeUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Header Glow Animation */
    @keyframes headerGlow {
        0% { text-shadow: 0 0 5px #ffe066, 0 0 10px #ffd633; }
        50% { text-shadow: 0 0 15px #ffe066, 0 0 25px #ffd633; }
        100% { text-shadow: 0 0 5px #ffe066, 0 0 10px #ffd633; }
    }

    /* Card Glow Animation */
    .announcement-card::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,221,87,0.3) 0%, rgba(255,221,87,0) 70%);
        animation: cardGlow 3s infinite;
        pointer-events: none;
    }
    @keyframes cardGlow {
        0% { transform: rotate(0deg); }
        50% { transform: rotate(180deg); }
        100% { transform: rotate(360deg); }
    }

    /* No Announcements Text */
    .no-announcements {
        text-align: center;
        color: #7a5e00;
        font-size: 18px;
        padding: 40px 0;
    }
</style>
</head>
<body>

    <!-- TOP NAVIGATION -->
    <nav class="top-nav">
        <a href="cas_home.php" id="backBtn">⬅ Back</a>
    </nav>

    <!-- PAGE HEADER -->
    <header class="edu-header fade-in">
        <h1>College of Arts and Sciences Announcements</h1>
    </header>

    <!-- ANNOUNCEMENT LIST -->
    <main class="announcement-container fade-up">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='announcement-card'>";
                echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
                echo "<p class='announcement-content'>" . nl2br(htmlspecialchars($row['Content'])) . "</p>";
                echo "<p class='announcement-date'>Posted: " . htmlspecialchars($row['Date_posted']) . "</p>";

                // Feedback Button
                echo "<a href='cas_feedback.php?announcement_id=" . $row['announcement_id'] . "' class='feedback-btn'>Give Feedback</a>";
                echo "</div>";
            }
        } else {
            echo "<p class='no-announcements'>No announcements available.</p>";
        }
        ?>
    </main>

</body>
</html>
