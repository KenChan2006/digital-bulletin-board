<?php
session_start();

// --- DB CONNECTION
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- FETCH ALL APPROVED ENGINEERING ANNOUNCEMENTS
$sql = "SELECT * FROM eng_announcement WHERE status='approved' ORDER BY DatePosted DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Engineering Announcements</title>
<style>
    /* GENERAL STYLING */
    body {
        font-family: Arial, sans-serif;
        background: #fff0f0;
        margin: 0;
        padding-bottom: 40px;
        transition: background 0.3s ease;
    }

    nav.top-nav {
        display: flex;
        align-items: center;
        gap: 20px;
        background: #ffe5e5;
        padding: 15px 20px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    nav.top-nav a#backBtn {
        text-decoration: none;
        color: #d32f2f;
        font-weight: bold;
        transition: color 0.2s;
    }
    nav.top-nav a#backBtn:hover {
        color: #9a0000;
    }

    header.edu-header {
        text-align: center;
        padding: 40px 20px;
        background: #ffcccc;
        border-radius: 0 0 20px 20px;
        margin-bottom: 20px;
        animation: fadeInHeader 0.8s ease forwards;
    }
    header.edu-header h1 {
        margin: 0;
        font-size: 28px;
        color: #b71c1c;
    }

    main.announcement-container {
        display: flex;
        flex-direction: column;
        gap: 20px;
        padding: 20px;
    }

    .announcement-card {
        background: #fff5f5;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        transition: transform 0.3s, box-shadow 0.3s;
        opacity: 0;
        transform: translateY(20px);
        animation: fadeUpCard 0.8s ease forwards;
    }
    .announcement-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }

    .announcement-content {
        margin: 10px 0;
        color: #4d0000;
    }

    .announcement-date {
        font-size: 0.9em;
        color: #800000;
    }

    .feedback-btn {
        display: inline-block;
        padding: 8px 15px;
        background: #d32f2f;
        color: #fff;
        border-radius: 8px;
        text-decoration: none;
        margin-top: 10px;
        transition: background 0.3s, transform 0.2s;
    }
    .feedback-btn:hover {
        background: #9a0000;
        transform: translateY(-2px);
    }

    /* ANIMATIONS */
    @keyframes fadeInHeader {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeUpCard {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
</head>
<body>

    <!-- TOP NAV BAR -->
    <nav class="top-nav">
        <a href="eng_home.php" id="backBtn">⬅ Back</a>
        <h2>College of Engineering</h2>
    </nav>

    <!-- PAGE HEADER -->
    <header class="edu-header">
        <h1>College of Engineering Announcements</h1>
    </header>

    <!-- ANNOUNCEMENT LIST -->
    <main class="announcement-container">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='announcement-card'>";
                echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
                echo "<p class='announcement-content'>" . nl2br(htmlspecialchars($row['Content'])) . "</p>";
                echo "<p class='announcement-date'>Posted: " . htmlspecialchars($row['DatePosted']) . "</p>";

                // FEEDBACK BUTTON
                echo "<a href='eng_feedback.php?announcement_id=" . $row['announcement_id'] . "' class='feedback-btn'>Give Feedback</a>";

                echo "</div>";
            }
        } else {
            echo "<p style='text-align:center; color:#800000; font-size:18px;'>No announcements available.</p>";
        }
        ?>
    </main>

    <script>
        // Stagger animation for cards
        const cards = document.querySelectorAll('.announcement-card');
        cards.forEach((card, index) => {
            card.style.animationDelay = (index * 0.15) + 's';
        });
    </script>

</body>
</html>
