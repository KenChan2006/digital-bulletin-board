<?php
session_start();

// --- DEBUGGING ---
ini_set('display_errors', 1);
error_reporting(E_ALL);

// --- DB CONNECTION ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- SESSION DATA FROM FIRST PAGE ---
$user_id = $_SESSION['user_id'] ?? null;  // `user_id` is already in session
$fname   = $_SESSION['fname'] ?? '';
$mname   = $_SESSION['mname'] ?? '';
$lname   = $_SESSION['lname'] ?? '';
$email   = $_SESSION['email'] ?? ''; // Retrieve email from session
$role    = $_SESSION['role'] ?? ''; // Assuming role is saved in the session

$error = "";

// --- HANDLE STUDENT REGISTRATION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_student'])) {

    if (!$user_id) {
        $error = "Session expired. Please register again.";
    } else if ($role !== 'student') {
        $error = "Invalid user role. Only students can register here.";
    } else {

        $password_raw = isset($_POST['password']) ? trim($_POST['password']) : ''; 
        $school_ID    = isset($_POST['school_ID']) ? trim($_POST['school_ID']) : '';
        $college      = isset($_POST['college']) ? $_POST['college'] : ''; 
        if (empty($password_raw) || empty($school_ID) || empty($college)) {
            $error = "Please fill in all fields.";
        } else {

            $password = password_hash($password_raw, PASSWORD_DEFAULT);

            // --- Update user table ---
            $stmt_update = $conn->prepare(
                "UPDATE user SET password=?, firstname=?, middlename=?, lastname=? WHERE id=?"
            );
            $stmt_update->bind_param("ssssi", $password, $fname, $mname, $lname, $user_id);

            if ($stmt_update->execute()) {

                // --- Insert into studentuser table ---
                $stmt_studentuser = $conn->prepare(
                    "INSERT INTO studentuser (user_id, school_ID, college, first_name, middle_name, last_name, email) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)"
                );
                $stmt_studentuser->bind_param("issssss", $id, $school_ID, $college, $fname, $mname, $lname, $email);

                if ($stmt_studentuser->execute()) {
                    $success = "Registration successful!";

                    // --- Set session variables ---
                    $_SESSION['college'] = $college;
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['fname']   = $fname;
                    $_SESSION['mname']   = $mname;
                    $_SESSION['lname']   = $lname;
                    $_SESSION['email']   = $email;

                    // --- Redirect based on college ---
                    switch (strtoupper($college)) {
                        case 'CAS':
                            header("Location: /studentDashboard/cas_home.php");
                            break;
                        case 'EDUC':
                            header("Location: /studentDashboard/educ_home.php");
                            break;
                        case 'AGRICULTURE':
                        case 'AGRI':
                            header("Location: /studentDashboard/agriculture_home.php");
                            break;
                        case 'ENGINEERING':
                            header("Location: /studentDashboard/eng_home.php");
                            break;
                        case 'IT':
                            header("Location: /studentDashboard/it_home.php");
                            break;
                        default:
                            $error = "College not recognized. Contact admin.";
                            break;
                    }
                    exit();

                } else {
                    $error = "Failed to register student data: " . $stmt_studentuser->error;
                }
                $stmt_studentuser->close();

            } else {
                $error = "Database error: " . $stmt_update->error;
            }
            $stmt_update->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration – Digital Bulletin Board</title>
    <link rel="stylesheet" href="/digitalDesign/student.css">
</head>
<body>

<div class="container fade-in">
    <h1 class="title">Student Registration</h1>

    <div class="card slide-up">

        <!-- Display error or success messages -->
        <?php if (!empty($error)): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php elseif (!empty($success)): ?>
            <p class="success-message"><?php echo $success; ?></p>
        <?php endif; ?>

        <form method="POST">

            <!-- Display names from PHP session -->
            <div class="input-group">
                <input type="text" value="<?php echo htmlspecialchars($fname); ?>" disabled placeholder="First Name">
            </div>

            <div class="input-group">
                <input type="text" value="<?php echo htmlspecialchars($mname); ?>" disabled placeholder="Middle Name">
            </div>

            <div class="input-group">
                <input type="text" value="<?php echo htmlspecialchars($lname); ?>" disabled placeholder="Last Name">
            </div>

            <!-- Display email from session, but not editable -->
            <div class="input-group">
                <input type="email" value="<?php echo htmlspecialchars($email); ?>" disabled placeholder="Email">
            </div>

            <div class="input-group">
                <input name="password" type="password" placeholder="Set Password" required>
            </div>

            <div class="input-group">
                <input name="school_ID" type="text" placeholder="School ID" required>
            </div>

            <select name="college" class="select" required>
                <option value="">Select College</option>
                <option value="CAS">College of Arts & Sciences</option>
                <option value="ENGINEERING">College of Engineering</option>
                <option value="AGRICULTURE">College of Agriculture</option>
                <option value="IT">College of Industrial Technology</option>
                <option value="EDUC">College of Education</option>
            </select>

            <button type="submit" name="register_student" class="btn">Sign Up</button>
        </form>

    </div>

    <p class="credits">Created by: Baril Alvin • Ebora Leonel • Alexander Jerome Tequillo</p>

</div>

</body>
</html>
