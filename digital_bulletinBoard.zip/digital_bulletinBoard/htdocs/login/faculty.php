<?php
session_start();

// Require faculty session
if (!isset($_SESSION['faculty_id']) || !isset($_SESSION['email'])) {
    // kung walang session, balik sa register o faculty landing
    header("Location: register.php");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];
$faculty_id = $_SESSION['faculty_id'];
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = trim($_POST['password']);
    $password_confirm = trim($_POST['password_confirm'] ?? '');

    if (empty($password)) {
        $error = "Please enter a password.";
    } elseif ($password !== $password_confirm) {
        $error = "Passwords do not match.";
    } else {
        // Optional: enforce minimum password length
        if (strlen($password) < 6) {
            $error = "Password must be at least 6 characters.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Update user table password where id = faculty_id (which is user id)
            $stmt = $conn->prepare("UPDATE user SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashedPassword, $faculty_id);

            if ($stmt->execute()) {
               
                header("Location: faculty_verification.php");
                exit();
            } else {
                $error = "Failed to update password. Please try again.";
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Set Faculty Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('/digital_asset/digital_background.jpeg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            width: 360px;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 16px;
        }

        .input-field {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 10px;
            border: none;
            border-radius: 6px;
            background: #2575fc;
            color: white;
            cursor: pointer;
        }

        p.error { color: red; text-align: center; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Set Faculty Password</h2>

    <?php if (!empty($error)) { echo '<p class="error">'.htmlspecialchars($error).'</p>'; } ?>

    <form method="POST" action="">
        <input type="password" name="password" class="input-field" placeholder="Enter password" required>
        <input type="password" name="password_confirm" class="input-field" placeholder="Confirm password" required>
        <button type="submit">Save Password</button>
    </form>
</div>

</body>
</html>
