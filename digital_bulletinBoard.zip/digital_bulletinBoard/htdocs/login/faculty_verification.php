<?php
session_start();

/*  
    When the form is submitted (POST), check the credentials.

    If correct:
        → Set session
        → Redirect to correct dashboard
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $user = $_POST['facultyUser'] ?? "";
    $pass = $_POST['facultyPass'] ?? "";
    $dept = $_POST['facultySelect'] ?? "";

    // Default faculty accounts
    $accounts = [
        "EDUC" => [
            "username" => "educ@faculty",
            "password" => "educ123",
            "redirect" => "/faculty/educ.php"
        ],
        "CAS" => [
            "username" => "cas@faculty",
            "password" => "cas123",
            "redirect" => "/faculty/cas.php"
        ],
        "IT" => [
            "username" => "it@faculty",
            "password" => "it123",
            "redirect" => "/faculty/IT.php"
        ],
        "ENG" => [
            "username" => "engineering@faculty",
            "password" => "eng123",
            "redirect" => "/faculty/eng.php"
        ],
        "AGRI" => [
            "username" => "agri@faculty",
            "password" => "agri123",
            "redirect" => "/faculty/agri.php"
        ]
    ];

    if (isset($accounts[$dept])) {
        $acc = $accounts[$dept];

        if ($user === $acc["username"] && $pass === $acc["password"]) {

            // SESSION CREATION (IMPORTANT)
            $_SESSION["user_id"] = rand(10000, 99999);
            $_SESSION["role"] = "faculty";
            $_SESSION["email"] = $acc["username"];
            $_SESSION["department"] = $dept;

            header("Location: " . $acc["redirect"]);
            exit();
        } else {
            $error = "Incorrect username or password.";
        }
    } else {
        $error = "Please select a faculty department.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Faculty Verification</title>
    <link rel="stylesheet" href="/digitalDesign/faculty_verification.css">
</head>
<body>

<div class="container fade-in">
    <div class="verify-box slide-up">

        <h1 class="title">Faculty Verification</h1>

        <!-- LOGIN FORM -->
        <form method="POST">

            <div class="input-group">
                <input type="text" name="facultyUser" id="facultyUser" placeholder="Username" required>
            </div>

            <div class="input-group">
                <input type="password" name="facultyPass" id="facultyPass" placeholder="Password" required>
            </div>

            <select name="facultySelect" id="facultySelect" class="select" required>
                <option value="">Select Faculty</option>
                <option value="EDUC">Education</option>
                <option value="CAS">Arts & Sciences</option>
                <option value="IT">Industrial Technology</option>
                <option value="ENG">Engineering</option>
                <option value="AGRI">Agriculture</option>
            </select>

            <button class="btn" type="submit">Verify</button>
        </form>

        <!-- ERROR MESSAGE -->
        <?php if (!empty($error)): ?>
            <p class="error shake"><?= $error ?></p>
        <?php endif; ?>

    </div>
</div>

        <script scr="faculty_verification.js"></script>

</body>
</html>
