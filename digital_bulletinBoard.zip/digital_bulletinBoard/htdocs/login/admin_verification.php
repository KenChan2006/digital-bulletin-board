<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/digitalDesign/admin_verification.css">
    <title>Admin Verification</title>
</head>

<body>
    <div class="container fade-in">
        <div class="verify-box slide-up">
            <h1 class="title">Admin Verification</h1>

            <div class="input-group">
                <input type="text" id="adminUser" placeholder="Enter Admin Username" required>
            </div>

            <div class="input-group">
                <input type="password" id="adminPass" placeholder="Enter Admin Password" required>
            </div>

            <button class="btn" id="verifyBtn">Verify</button>

            <p id="error" class="error"></p>
        </div>
    </div>

    <script src="../digitaljs/admin_verification.js"></script>
</body>
</html>
