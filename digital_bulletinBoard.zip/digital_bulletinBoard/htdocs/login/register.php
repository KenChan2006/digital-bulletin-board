<?php
session_start();

// --- Database connection ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $firstname  = trim($_POST['fn']);
    $middlename = trim($_POST['mn']);
    $lastname   = trim($_POST['ln']);
    $email      = trim($_POST['em']);
    $role       = trim($_POST['op']);

    if ($firstname && $middlename && $lastname && $email && $role) {

        // Check duplicate email
        $check = $conn->prepare("SELECT id FROM user WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "Email already exists!";
            $check->close();
        } else {
            $check->close();

            // Insert into user table (password left empty for now)
            $stmt = $conn->prepare(
                "INSERT INTO user (firstname, middlename, lastname, email, role, password)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            // store empty password for now (or NULL if your column allows it)
            $empty_password = "";
            $stmt->bind_param("ssssss", $firstname, $middlename, $lastname, $email, $role, $empty_password);

            if ($stmt->execute()) {

                // Store session values
                $_SESSION['user_id']  = $stmt->insert_id;
                $_SESSION['fname']    = $firstname;
                $_SESSION['mname']    = $middlename;
                $_SESSION['lname']    = $lastname;
                $_SESSION['role']     = $role;
                $_SESSION['email']    = $email;

                // If faculty, use the same user_id as faculty_id and require password setup
                if ($role === "faculty") {
                    $_SESSION['faculty_id'] = $_SESSION['user_id'];
                    header("Location: faculty.php");
                    exit();
                }

                // Redirects for other roles
                if ($role === "student") {
                    header("Location: student.php");
                    exit();
                }

                if ($role === "admin") {
                    header("Location: admin.php");
                    exit();
                }

            } else {
                $error = "Failed to register. Please try again.";
            }

            $stmt->close();
        }
    } else {
        $error = "Please complete all fields.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Digital Bulletin Board – Register</title>
    <link rel="stylesheet" href="/digitalDesign/register.css">
</head>
<body>

<div class="container fade-in">
    <h1 class="title">Digital Bulletin Board</h1>

    <div class="card">
        <h2 class="subtitle">Create Account</h2>

        <?php
        if (!empty($error)) {
            echo '<p style="color:red;">' . htmlspecialchars($error) . '</p>';
        }
        ?>

        <form method="POST" action="">
            <div class="input-group">
                <input type="text" name="fn" placeholder="First Name" required>
            </div>

            <div class="input-group">
                <input type="text" name="mn" placeholder="Middle Name" required>
            </div>

            <div class="input-group">
                <input type="text" name="ln" placeholder="Last Name" required>
            </div>

            <div class="input-group">
                <input type="email" name="em" placeholder="Email" required>
            </div>

            <label class="label">Select Role</label>
            <select name="op" class="select" required>
                <option value="">Select...</option>
                <option value="admin">Admin</option>
                <option value="faculty">Faculty</option>
                <option value="student">Student</option>
            </select>

            <button class="btn" name="register">Register</button>
        </form>

        <a href="login.php" class="link">Already have an account?</a>
        <a href="admin_login.php" class="link">Already have an account as an admin?</a>
        <a href="faculty_login.php" class="link">Already have an account as a faculty?</a>
    </div>
</div>

</body>
</html>
