<?php
session_start();

// Check if user data is stored in session
if (!isset($_SESSION['user_id'])) {
    header("Location: register.php"); 
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];
$error = "";

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // NOTE: name changed from "password" to "admin_key"
    $password = trim($_POST['admin_key']);

    if (empty($password)) {
        $error = "Please enter a password.";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert user data into the database
        $stmt = $conn->prepare("UPDATE user SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashedPassword, $email);

        if ($stmt->execute()) {
            echo "Password updated successfully!";
            header("Location: admin_verification.php");
            exit();
        } else {
            $error = "Failed to update password. Please try again.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Admin Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('/digital_asset/digital_background.jpeg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.8);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            width: 350px;
            animation: slideIn 1s ease-out;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        .input-field {
            width: 100%;
            padding: 12px;
            margin: 15px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
            outline: none;
            transition: border-color 0.3s ease;
        }

        .input-field:focus {
            border-color: #2575fc;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #2575fc;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #6a11cb;
        }

        p {
            font-size: 14px;
            color: red;
            text-align: center;
        }

        @keyframes slideIn {
            0% {
                transform: translateY(-50px);
                opacity: 0;
            }
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Set Admin Password</h2>

    <!-- Disable all autocomplete -->
    <form method="POST" action="" autocomplete="off">

        <!-- Fake fields to block Microsoft Edge autofill -->
        <input type="text" name="fakeuser" style="display:none;">
        <input type="password" name="fakepass" style="display:none;">

        <!-- REAL password field with safe name -->
        <input 
            type="password" 
            name="admin_key" 
            class="input-field" 
            placeholder="Enter Password"
            autocomplete="new-password"
            required
        ><br>

        <button type="submit">Set Password</button>
        
        <?php
        if (!empty($error)) {
            echo "<p>$error</p>";
        }
        ?>
    </form>
</div>

</body>
</html>
