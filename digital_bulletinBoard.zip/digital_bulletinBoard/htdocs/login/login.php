<?php
session_start();

// --- Database connection ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

// Pre-fill email after registration
$pre_email = $_SESSION['pre_email'] ?? '';
unset($_SESSION['pre_email']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email     = trim($_POST['email']);
    $password  = trim($_POST['password']);

    if ($email && $password) {

        /*
        STEP 1:
        - CHECK USER TABLE (email + password)
        - MATCH WITH STUDENTUSER USING EMAIL
        */

        $stmt = $conn->prepare("
            SELECT 
                user.id,
                user.firstname,
                user.middlename,
                user.lastname,
                user.password,
                studentuser.college
            FROM user
            INNER JOIN studentuser
                ON studentuser.email = user.email
            WHERE user.email = ?
            LIMIT 1
        ");

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {

            $row = $result->fetch_assoc();

            // STEP 2: VERIFY PASSWORD
            if (password_verify($password, $row['password'])) {

                $college_raw = $row['college'];

                if (!$college_raw) {
                    $error = "This student has no assigned college.";
                } else {

                    // Normalize
                    $college = strtoupper(trim($college_raw));

                    // VALID COLLEGE LIST
                    $dashboard = [
                        'CAS' => '/studentDashboard/cas_home.php',
                        'EDUC' => '/studentDashboard/educ_home.php',
                        'AGRI' => '/studentDashboard/agriculture_home.php',
                        'ENGINEERING' => '/studentDashboard/eng_home.php',
                        'IT' => '/studentDashboard/it_home.php'
                    ];

                    // Fuzzy match for long names
                    if (!isset($dashboard[$college])) {
                        if (str_contains($college, "CAS")) $college = "CAS";
                        if (str_contains($college, "EDUC")) $college = "EDUC";
                        if (str_contains($college, "AGRI")) $college = "AGRI";
                        if (str_contains($college, "ENG"))  $college = "ENGINEERING";
                        if (str_contains($college, "IT"))   $college = "IT";
                    }

                    if (isset($dashboard[$college])) {

                        // SET SESSION
                        $_SESSION['user_id'] = $row['id'];
                        $_SESSION['fname']   = $row['firstname'];
                        $_SESSION['mname']   = $row['middlename'];
                        $_SESSION['lname']   = $row['lastname'];
                        $_SESSION['email']   = $email;
                        $_SESSION['college'] = $college;

                        // REDIRECT
                        header("Location: " . $dashboard[$college]);
                        exit();

                    } else {
                        $error = "Invalid college value: " . $college_raw;
                    }
                }

            } else {
                $error = "Incorrect password.";
            }

        } else {
            $error = "Account not found.";
        }

        $stmt->close();

    } else {
        $error = "Please enter your email and password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Login – Digital Bulletin Board</title>
    <link rel="stylesheet" href="/digitalDesign/login.css">
</head>
<body>

<div class="container fade-in">

    <h1 class="title">Digital Bulletin Board</h1>

    <div class="card slide-up">

        <h2 class="subtitle">Log In</h2>

        <?php 
        if (!empty($error)) {
            echo '<p style="color:red;">' . htmlspecialchars($error) . '</p>';
        }
        ?>

        <form method="POST" autocomplete="off">

            <!-- Dummy fields to block autofill -->
            <input type="text" name="fakeuser" style="display:none;">
            <input type="password" name="fakepass" style="display:none;">

            <div class="input-group">
                <input id="num" 
                       type="email" 
                       name="email" 
                       placeholder="Email"
                       value="<?php echo htmlspecialchars($pre_email); ?>"
                       required>
            </div>

            <div class="input-group">
                <input id="pass" 
                       type="password" 
                       name="password" 
                       placeholder="Password" 
                       autocomplete="new-password"
                       required>
            </div>

            <button id="buton2" class="btn" type="submit">Log In</button>

            <a href="register.php" class="link">Don't have an account? Register here</a>
        </form>

    </div>

    <p class="credits">Created by: Baril Alvin, Ebora Leonel, Alexander Jerome Tequillo</p>

</div>

</body>
</html>
