<?php
session_start();

// --- Database connection ---
$conn = new mysqli("localhost", "root", "", "digital_bulletin_board");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

// For consistency with student version (but admins don't prefill)
$pre_email = $_SESSION['pre_email'] ?? '';
unset($_SESSION['pre_email']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($email && $password) {

        // Check for admin account
        $stmt = $conn->prepare(
            "SELECT id, firstname, middlename, lastname, password 
             FROM user 
             WHERE email=? AND role='admin'
             LIMIT 1"
        );

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {

            $stmt->bind_result($admin_id, $fname, $mname, $lname, $hash);
            $stmt->fetch();

            // Verify password
            if (password_verify($password, $hash)) {

                // Save admin session
                $_SESSION['admin_id'] = $admin_id;
                $_SESSION['fname']    = $fname;
                $_SESSION['mname']    = $mname;
                $_SESSION['lname']    = $lname;
                $_SESSION['email']    = $email;
                $_SESSION['role']     = "admin";

                // Redirect admin
                header("Location: admin_verification.php");
                exit();

            } else {
                $error = "Incorrect password.";
            }

        } else {
            $error = "Admin account not found.";
        }

        $stmt->close();

    } else {
        $error = "Please fill in all fields.";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login – Digital Bulletin Board</title>
    <link rel="stylesheet" href="/digitalDesign/login.css">
</head>
<body>

<div class="container fade-in">

    <h1 class="title">Digital Bulletin Board</h1>

    <div class="card slide-up">
        <h2 class="subtitle">Admin Log In</h2>

        <?php 
        if (!empty($error)) {
            echo '<p style="color:red;">' . htmlspecialchars($error) . '</p>';
        }
        ?>

        <form method="POST" autocomplete="off">

            <div class="input-group">
                <input type="email" name="email" placeholder="Email"
                       value="<?php echo htmlspecialchars($pre_email); ?>" required>
            </div>

            <div class="input-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <button id="buton2" class="btn" type="submit">Log In</button>

            <a href="register.php" class="link">Don't have an account? Register here</a>

        </form>
    </div>

    <p class="credits">Created by: Baril Alvin, Ebora Leonel, Alexander Jerome Tequillo</p>

</div>

</body>
</html>
